package com.example.printxpress.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.printxpress.R;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.OrderDAO;
import com.example.printxpress.database.ProductDAO;
import com.example.printxpress.models.Order;
import com.example.printxpress.models.Product;
import com.example.printxpress.utils.NotificationHelper;
import com.example.printxpress.utils.SessionManager;
import com.example.printxpress.utils.ValidationHelper;

public class PlaceOrderActivity
        extends AppCompatActivity {

    private static final int PICK_FILE = 101;

    private TextInputLayout tilQty, tilPaper,
            tilCustomText, tilAddress;
    private TextInputEditText etQty, etCustomText,
            etAddress;
    private AutoCompleteTextView actvPaper;
    private RadioGroup rgDelivery;
    private MaterialButton btnUpload,
            btnConfirm, btnCancel, btnPickAddress;
    private TextView tvProductName, tvMeta,
            tvPrice, tvFileName,
            tvUnitPrice, tvQty, tvTotal, tvDiscount;
    private android.widget.ImageView ivDesignPreview, ivOrderProductImage;

    private Product product;
    private OrderDAO orderDAO;
    private ProductDAO productDAO;
    private com.example.printxpress.database.AddressDAO addressDAO;
    private SessionManager session;
    private NotificationHelper notifHelper;
    private com.example.printxpress.utils.FileUploadHelper fileHelper;
    private String fileURI = null;
    private Uri selectedFileUri = null;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_place_order);

        orderDAO = new OrderDAO(this);
        productDAO = new ProductDAO(this);
        addressDAO = new com.example.printxpress.database.AddressDAO(this);
        session = new SessionManager(this);
        notifHelper = new NotificationHelper(this);
        fileHelper = new com.example.printxpress.utils.FileUploadHelper(this);

        initViews();
        loadProduct();
        setupPaperTypes();
        setListeners();
    }

    private void initViews() {
        tilQty = findViewById(R.id.tilQuantity);
        tilPaper = findViewById(R.id.tilPaperType);
        tilCustomText = findViewById(
                R.id.tilCustomText);
        tilAddress = findViewById(
                R.id.tilDeliveryAddress);
        etQty = findViewById(R.id.etQuantity);
        etCustomText = findViewById(
                R.id.etCustomText);
        etAddress = findViewById(
                R.id.etDeliveryAddress);
        actvPaper = findViewById(
                R.id.actvPaperType);
        rgDelivery = findViewById(R.id.rgDelivery);
        btnUpload = findViewById(
                R.id.btnUploadDesign);
        btnConfirm = findViewById(
                R.id.btnConfirmOrder);
        btnCancel = findViewById(
                R.id.btnCancelOrder);
        btnPickAddress = findViewById(R.id.btnPickAddress);
        tvProductName = findViewById(
                R.id.tvOrderProductName);
        tvMeta = findViewById(
                R.id.tvOrderProductMeta);
        tvPrice = findViewById(
                R.id.tvOrderProductPrice);
        tvFileName = findViewById(R.id.tvFileName);
        tvUnitPrice = findViewById(
                R.id.tvSummaryUnitPrice);
        tvQty = findViewById(R.id.tvSummaryQty);
        tvTotal = findViewById(R.id.tvSummaryTotal);
        tvDiscount = findViewById(
                R.id.tvSummaryDiscount);
        ivDesignPreview = findViewById(R.id.ivDesignPreview);
        ivOrderProductImage = findViewById(R.id.ivOrderProductImage);
    }

    private void loadProduct() {
        int pid = getIntent().getIntExtra(
                AppConstants.KEY_PRODUCT_ID, -1);
        if (pid == -1) { finish(); return; }
        product = productDAO.getProductByID(pid);
        if (product == null) { finish(); return; }

        tvProductName.setText(product.getName());
        tvMeta.setText(product.getMaterial() +
                " | " + product.getSize());
        tvPrice.setText(String.format(
                "LKR %.2f", product.getPrice()));
        tvUnitPrice.setText(String.format(
                "LKR %.2f", product.getPrice()));

        if (product.getImage() != null && !product.getImage().isEmpty()) {
            try {
                ivOrderProductImage.setImageURI(Uri.parse(product.getImage()));
            } catch (Exception e) {
                ivOrderProductImage.setImageResource(R.drawable.logo);
            }
        } else {
            ivOrderProductImage.setImageResource(R.drawable.logo);
        }

        updateSummary();
    }

    private void setupPaperTypes() {
        String[] papers = {
                "130gsm Silk", "170gsm Silk",
                "200gsm Matt", "250gsm Matt",
                "300gsm Gloss", "350gsm Matt",
                "400gsm Gloss", "PVC Vinyl"
        };
        actvPaper.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout
                        .simple_dropdown_item_1line,
                papers));
        actvPaper.setText(papers[0], false);
    }

    private void setListeners() {
        rgDelivery.setOnCheckedChangeListener(
                (g, id) -> {
                    boolean isDelivery = id == R.id.rbDelivery;
                    tilAddress.setVisibility(
                            isDelivery ?
                                    View.VISIBLE : View.GONE);
                    btnPickAddress.setVisibility(
                            isDelivery ?
                                    View.VISIBLE : View.GONE);
                    
                    if (isDelivery) {
                        checkAndFillDefaultAddress();
                    }
                });

        btnPickAddress.setOnClickListener(v -> showAddressPicker());

        etQty.addTextChangedListener(
                new android.text.TextWatcher() {
                    public void beforeTextChanged(
                            CharSequence s,
                            int a, int b, int c) {}
                    public void onTextChanged(
                            CharSequence s,
                            int a, int b, int c) {
                        updateSummary();
                    }
                    public void afterTextChanged(
                            android.text.Editable s) {}
                });

        btnUpload.setOnClickListener(v -> {
            Intent i = new Intent(
                    Intent.ACTION_GET_CONTENT);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES,
                    new String[]{
                            "application/pdf",
                            "image/jpeg",
                            "image/png"});
            startActivityForResult(
                    Intent.createChooser(i,
                            "Select Design"),
                    PICK_FILE);
        });

        btnConfirm.setOnClickListener(v ->
                placeOrder());
        btnCancel.setOnClickListener(v -> finish());
    }

    @Override
    protected void onActivityResult(
            int requestCode, int resultCode,
            Intent data) {
        super.onActivityResult(
                requestCode, resultCode, data);
        if (requestCode == PICK_FILE &&
                resultCode == Activity.RESULT_OK &&
                data != null &&
                data.getData() != null) {
            selectedFileUri = data.getData();
            fileURI = selectedFileUri.toString();
            
            String fileName = fileHelper.getFileName(selectedFileUri);
            tvFileName.setText(fileName != null ? fileName : "File selected");
            tvFileName.setVisibility(View.VISIBLE);
            btnUpload.setText("Change File");

            // Show preview if it's an image
            String mime = getContentResolver().getType(selectedFileUri);
            if (mime != null && mime.startsWith("image/")) {
                ivDesignPreview.setImageURI(selectedFileUri);
                ivDesignPreview.setVisibility(View.VISIBLE);
            } else {
                ivDesignPreview.setVisibility(View.GONE);
            }
        }
    }

    private void checkAndFillDefaultAddress() {
        new Thread(() -> {
            java.util.List<com.example.printxpress.models.Address> addresses = addressDAO.getAddressByUser(session.getUserID());
            for (com.example.printxpress.models.Address a : addresses) {
                if (a.isDefault()) {
                    runOnUiThread(() -> etAddress.setText(a.getAddressLine() + ", " + a.getCity()));
                    break;
                }
            }
        }).start();
    }

    private void showAddressPicker() {
        new Thread(() -> {
            java.util.List<com.example.printxpress.models.Address> addresses = addressDAO.getAddressByUser(session.getUserID());
            if (addresses.isEmpty()) {
                runOnUiThread(() -> Toast.makeText(this, "No saved addresses", Toast.LENGTH_SHORT).show());
                return;
            }

            String[] items = new String[addresses.size()];
            for (int i = 0; i < addresses.size(); i++) {
                items[i] = addresses.get(i).getAddressLine() + ", " + addresses.get(i).getCity();
            }

            runOnUiThread(() -> {
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Select Address")
                        .setItems(items, (d, which) -> {
                            etAddress.setText(items[which]);
                        })
                        .show();
            });
        }).start();
    }

    private void updateSummary() {
        if (product == null) return;
        String qStr = etQty.getText() != null ?
                etQty.getText().toString() : "1";
        int qty;
        try {
            qty = Math.max(1,
                    Integer.parseInt(qStr));
        } catch (Exception ignored) {
            qty = 1;
        }
        double total = product.getPrice() * qty;
        tvQty.setText(String.valueOf(qty));
        tvDiscount.setText("LKR 0.00");
        tvTotal.setText(String.format(
                "LKR %.2f", total));
    }

    private void placeOrder() {
        String qStr = etQty.getText() != null ?
                etQty.getText().toString().trim()
                : "";
        String customText =
                etCustomText.getText() != null ?
                        etCustomText.getText().toString()
                                .trim() : "";
        String paper = actvPaper.getText()
                .toString().trim();
        boolean isDelivery =
                rgDelivery.getCheckedRadioButtonId()
                        == R.id.rbDelivery;
        String address =
                etAddress.getText() != null ?
                        etAddress.getText().toString()
                                .trim() : "";

        boolean valid = true;

        if (!ValidationHelper
                .isValidQuantity(qStr)) {
            tilQty.setError(
                    "Enter valid quantity (1-10000)");
            valid = false;
        } else tilQty.setError(null);

        if (customText.isEmpty() &&
                fileURI == null) {
            tilCustomText.setError(
                    "Add custom text or upload " +
                            "a design file");
            valid = false;
        } else tilCustomText.setError(null);

        if (isDelivery && address.isEmpty()) {
            tilAddress.setError(
                    "Delivery address required");
            valid = false;
        } else tilAddress.setError(null);

        if (!valid) return;

        int qty = Integer.parseInt(qStr);
        double total = product.getPrice() * qty;

        // Save a persistent copy of the file if one was selected
        String finalFilePath = fileURI;
        if (selectedFileUri != null) {
            String persistentPath = fileHelper.copyFileToInternal(selectedFileUri);
            if (persistentPath != null) {
                finalFilePath = persistentPath;
            }
        }

        Order order = new Order();
        order.setUserID(session.getUserID());
        order.setProductID(product.getProductID());
        order.setQuantity(qty);
        order.setPaperType(paper);
        order.setCustomText(customText);
        order.setFilePath(finalFilePath);
        order.setDeliveryType(isDelivery ?
                AppConstants.DELIVERY_HOME :
                AppConstants.DELIVERY_PICKUP);
        order.setDeliveryAddress(address);
        order.setTotalAmount(total);
        order.setStatus(
                AppConstants.STATUS_PROCESSING);

        btnConfirm.setEnabled(false);
        btnConfirm.setText("Processing...");

        long orderID = orderDAO.placeOrder(order);

        if (orderID != -1) {
            notifHelper.orderConfirmed(
                    (int) orderID,
                    session.getUserID());

            // Send email receipt
            sendOrderEmail(
                    (int) orderID,
                    order,
                    session.getUserEmail());

            new androidx.appcompat.app.AlertDialog
                    .Builder(this)
                    .setTitle("Order Placed!")
                    .setMessage("Order #" + orderID +
                            " placed successfully!")
                    .setPositiveButton("View Orders",
                            (d, w) -> {
                                Intent intent = new Intent(
                                        this,
                                        MainActivity.class);
                                intent.setFlags(
                                        Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                            })
                    .setCancelable(false)
                    .show();
        } else {
            Toast.makeText(this,
                    "Failed. Try again.",
                    Toast.LENGTH_SHORT).show();
            btnConfirm.setEnabled(true);
            btnConfirm.setText("Confirm Order");
        }
    }
    private void sendOrderEmail(int orderID,
                                Order order,
                                String customerEmail) {
        try {
            String subject =
                    "PrintXpress - Order Confirmation" +
                            " #" + String.format("%05d", orderID);

            String body =
                    "Dear Customer,\n\n" +
                            "Thank you for choosing " +
                            "PrintXpress!\n\n" +
                            "Your order has been placed " +
                            "successfully.\n\n" +
                            "================================\n" +
                            "ORDER DETAILS\n" +
                            "================================\n" +
                            "Order ID   : #" +
                            String.format("%05d", orderID) +
                            "\n" +
                            "Product    : " +
                            (product != null ?
                                    product.getName() : "-") + "\n" +
                            "Paper Type : " +
                            order.getPaperType() + "\n" +
                            "Quantity   : " +
                            order.getQuantity() + "\n" +
                            "Delivery   : " +
                            order.getDeliveryType() + "\n" +
                            "Status     : Processing\n" +
                            "Total      : LKR " +
                            String.format("%.2f",
                                    order.getTotalAmount()) + "\n" +
                            "================================\n\n" +
                            "We will notify you when your " +
                            "order is ready.\n\n" +
                            "For support:\n" +
                            "Email: support@printxpress.lk\n" +
                            "Phone: +94 11 234 5678\n" +
                            "WhatsApp: +94 77 234 5678\n\n" +
                            "Thank you,\n" +
                            "PrintXpress Team\n" +
                            "Design. Print. Deliver.";

            Intent emailIntent = new Intent(
                    Intent.ACTION_SEND);
            emailIntent.setType("message/rfc822");
            emailIntent.putExtra(
                    Intent.EXTRA_EMAIL,
                    new String[]{customerEmail});
            emailIntent.putExtra(
                    Intent.EXTRA_SUBJECT, subject);
            emailIntent.putExtra(
                    Intent.EXTRA_TEXT, body);

            startActivity(Intent.createChooser(
                    emailIntent,
                    "Send Order Receipt via..."));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
