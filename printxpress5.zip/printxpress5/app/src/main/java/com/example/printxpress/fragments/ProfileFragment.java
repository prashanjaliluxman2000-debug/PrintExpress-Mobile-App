package com.example.printxpress.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.printxpress.R;
import com.example.printxpress.activities.LoginActivity;
import com.example.printxpress.activities.MainActivity;
import com.example.printxpress.activities.SupportActivity;
import com.example.printxpress.activities.DesignGalleryActivity;
import com.example.printxpress.database.UserDAO;
import com.example.printxpress.database.AddressDAO;
import com.example.printxpress.models.User;
import com.example.printxpress.models.Address;
import com.example.printxpress.utils.SessionManager;
import com.example.printxpress.utils.ValidationHelper;
import java.util.List;

public class ProfileFragment extends Fragment {

    private TextView tvName, tvEmail;
    private LinearLayout rowEdit, rowPassword,
            rowOrders, rowAddresses, rowSavedDesigns,
            rowGuidelines, rowGallery, rowSupport, rowLogout;
    private UserDAO userDAO;
    private AddressDAO addressDAO;
    private SessionManager session;
    private User currentUser;

    @Nullable @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(
                R.layout.fragment_profile,
                container, false);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        userDAO = new UserDAO(requireContext());
        addressDAO = new AddressDAO(requireContext());
        session = new SessionManager(
                requireContext());
        currentUser = userDAO.getUserByID(
                MainActivity.loggedInUserID);

        initViews(view);
        loadData();
        setListeners();
    }

    private void initViews(View view) {
        tvName = view.findViewById(
                R.id.tvProfileName);
        tvEmail = view.findViewById(
                R.id.tvProfileEmail);
        rowEdit = view.findViewById(
                R.id.rowEditProfile);
        rowPassword = view.findViewById(
                R.id.rowChangePassword);
        rowOrders = view.findViewById(
                R.id.rowOrderHistory);
        rowAddresses = view.findViewById(
                R.id.rowAddresses);
        rowSavedDesigns = view.findViewById(
                R.id.rowSavedDesigns);
        rowGuidelines = view.findViewById(
                R.id.rowGuidelines);
        rowGallery = view.findViewById(
                R.id.rowGallery);
        rowSupport = view.findViewById(
                R.id.rowSupport);
        rowLogout = view.findViewById(R.id.rowLogout);
    }

    private void loadData() {
        if (currentUser == null) return;
        tvName.setText(currentUser.getName());
        tvEmail.setText(currentUser.getEmail());
    }

    private void setListeners() {
        rowEdit.setOnClickListener(v ->
                showEditDialog());
        rowPassword.setOnClickListener(v ->
                showPasswordDialog());
        rowOrders.setOnClickListener(v -> {
            if (getActivity() instanceof
                    MainActivity)
                ((MainActivity) getActivity())
                        .navigateToOrders();
        });
        rowAddresses.setOnClickListener(v ->
                showAddressesDialog());
        rowSavedDesigns.setOnClickListener(v ->
                Toast.makeText(getContext(),
                        "No saved designs yet",
                        Toast.LENGTH_SHORT).show());
        rowGuidelines.setOnClickListener(v ->
                showGuidelinesDialog());
        rowGallery.setOnClickListener(v ->
                startActivity(new Intent(getContext(), DesignGalleryActivity.class)));
        rowSupport.setOnClickListener(v ->
                startActivity(new Intent(
                        getContext(),
                        SupportActivity.class)));
        rowLogout.setOnClickListener(v ->
                confirmLogout());
    }

    private void showAddressesDialog() {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_notifications, null);
        androidx.recyclerview.widget.RecyclerView rv = view.findViewById(R.id.rvNotifications);
        LinearLayout layoutEmpty = view.findViewById(R.id.layoutEmpty);
        com.google.android.material.button.MaterialButton btnAdd = view.findViewById(R.id.btnMarkAllRead);
        
        // Hide the toolbar if it's there
        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            if (vg.getChildAt(0) instanceof com.google.android.material.appbar.MaterialToolbar) {
                vg.getChildAt(0).setVisibility(View.GONE);
            }
        }
        
        btnAdd.setText("Add New Address");
        btnAdd.setVisibility(View.VISIBLE);
        
        androidx.appcompat.app.AlertDialog dialog = new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Saved Addresses")
                .setView(view)
                .setPositiveButton("Close", null)
                .create();

        Runnable refreshList = new Runnable() {
            @Override
            public void run() {
                List<Address> newList = addressDAO.getAddressByUser(MainActivity.loggedInUserID);
                if (newList.isEmpty()) {
                    rv.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                    // Update text if we can find it
                    for (int i = 0; i < layoutEmpty.getChildCount(); i++) {
                        if (layoutEmpty.getChildAt(i) instanceof TextView) {
                            ((TextView) layoutEmpty.getChildAt(i)).setText("No saved addresses");
                        }
                    }
                } else {
                    rv.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                    
                    rv.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(getContext()));
                    rv.setAdapter(new androidx.recyclerview.widget.RecyclerView.Adapter<AddrVH>() {
                        @NonNull @Override
                        public AddrVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            return new AddrVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_address, parent, false));
                        }
                        @Override
                        public void onBindViewHolder(@NonNull AddrVH holder, int position) {
                            Address a = newList.get(position);
                            holder.line.setText(a.getAddressLine());
                            holder.city.setText(a.getCity());
                            holder.btnDel.setOnClickListener(v -> {
                                addressDAO.deleteAddress(a.getAddressID());
                                run(); // Refresh the list
                            });
                        }
                        @Override
                        public int getItemCount() { return newList.size(); }
                    });
                }
            }
        };

        btnAdd.setOnClickListener(v -> showAddAddressDialog(refreshList));

        dialog.show();
        refreshList.run();
    }

    private static class AddrVH extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        TextView line, city;
        View btnDel;
        AddrVH(View v) {
            super(v);
            line = v.findViewById(R.id.tvAddressLine);
            city = v.findViewById(R.id.tvCity);
            btnDel = v.findViewById(R.id.btnDeleteAddress);
        }
    }

    private void showAddAddressDialog(Runnable onAdded) {
        View dv = LayoutInflater.from(getContext()).inflate(R.layout.dialog_address, null);
        com.google.android.material.textfield.TextInputEditText etLine = dv.findViewById(R.id.etAddressLine);
        com.google.android.material.textfield.TextInputEditText etCity = dv.findViewById(R.id.etCity);
        android.widget.CheckBox cbDefault = dv.findViewById(R.id.cbDefaultAddress);

        new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Add New Address")
                .setView(dv)
                .setPositiveButton("Save", (d, w) -> {
                    String line = etLine.getText() != null ? etLine.getText().toString().trim() : "";
                    String city = etCity.getText() != null ? etCity.getText().toString().trim() : "";
                    if (line.isEmpty() || city.isEmpty()) {
                        Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Address a = new Address();
                    a.setUserID(MainActivity.loggedInUserID);
                    a.setAddressLine(line);
                    a.setCity(city);
                    a.setDefault(cbDefault.isChecked());
                    
                    long id = addressDAO.addAddress(a);
                    if (id != -1) {
                        Toast.makeText(getContext(), "Address added!", Toast.LENGTH_SHORT).show();
                        onAdded.run();
                    } else {
                        Toast.makeText(getContext(), "Failed to add address", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDialog() {
        if (currentUser == null) return;
        View dv = LayoutInflater.from(getContext())
                .inflate(
                        R.layout.dialog_edit_profile, null);
        TextInputLayout tilName =
                dv.findViewById(R.id.tilEditName);
        TextInputLayout tilPhone =
                dv.findViewById(R.id.tilEditPhone);
        TextInputEditText etName =
                dv.findViewById(R.id.etEditName);
        TextInputEditText etPhone =
                dv.findViewById(R.id.etEditPhone);

        etName.setText(currentUser.getName());
        etPhone.setText(currentUser.getPhone());

        new androidx.appcompat.app.AlertDialog
                .Builder(requireContext())
                .setTitle("Edit Profile")
                .setView(dv)
                .setPositiveButton("Update", (d, w) -> {
                    String name =
                            etName.getText() != null ?
                                    etName.getText().toString()
                                            .trim() : "";
                    String phone =
                            etPhone.getText() != null ?
                                    etPhone.getText().toString()
                                            .trim() : "";
                    if (!ValidationHelper
                            .isValidName(name)) {
                        tilName.setError(
                                "Enter valid name");
                        return;
                    }
                    if (!ValidationHelper
                            .isValidPhone(phone)) {
                        tilPhone.setError(
                                "Enter valid phone");
                        return;
                    }
                    currentUser.setName(name);
                    currentUser.setPhone(phone);
                    if (userDAO.updateUser(currentUser)) {
                        MainActivity.loggedInUserName =
                                name;
                        session.saveSession(
                                currentUser.getUserID(),
                                name,
                                currentUser.getEmail(),
                                false);
                        loadData();
                        Toast.makeText(getContext(),
                                "Profile updated!",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPasswordDialog() {
        View dv = LayoutInflater.from(getContext())
                .inflate(
                        R.layout.dialog_change_password,
                        null);
        TextInputLayout tilNew =
                dv.findViewById(R.id.tilNewPassword);
        TextInputLayout tilConfirm =
                dv.findViewById(
                        R.id.tilConfirmNewPassword);
        TextInputEditText etNew =
                dv.findViewById(R.id.etNewPassword);
        TextInputEditText etConfirm =
                dv.findViewById(
                        R.id.etConfirmNewPassword);

        new androidx.appcompat.app.AlertDialog
                .Builder(requireContext())
                .setTitle("Change Password")
                .setView(dv)
                .setPositiveButton("Update", (d, w) -> {
                    String newPwd =
                            etNew.getText() != null ?
                                    etNew.getText().toString()
                                    : "";
                    String confirm =
                            etConfirm.getText() != null ?
                                    etConfirm.getText().toString()
                                    : "";
                    if (!ValidationHelper
                            .isValidPassword(newPwd)) {
                        tilNew.setError(
                                "Min 6 chars, 1 uppercase, " +
                                        "1 number");
                        return;
                    }
                    if (!newPwd.equals(confirm)) {
                        tilConfirm.setError(
                                "Passwords do not match");
                        return;
                    }
                    userDAO.updatePassword(
                            MainActivity.loggedInUserID,
                            newPwd);
                    Toast.makeText(getContext(),
                            "Password updated!",
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showGuidelinesDialog() {
        String msg =
                "PRINT FILE REQUIREMENTS\n\n" +
                        "File Formats: PDF, JPG, PNG\n\n" +
                        "Color Mode: CMYK preferred\n\n" +
                        "Resolution: Minimum 300 DPI\n\n" +
                        "Bleed: 3mm on all sides\n\n" +
                        "Safe Zone: 5mm from edges\n\n" +
                        "Max File Size: 10MB";

        new androidx.appcompat.app.AlertDialog
                .Builder(requireContext())
                .setTitle("Design Guidelines")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    private void confirmLogout() {
        new androidx.appcompat.app.AlertDialog
                .Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure?")
                .setPositiveButton("Logout", (d, w) -> {
                    session.clearSession();
                    startActivity(new Intent(
                            getContext(),
                            LoginActivity.class));
                    requireActivity().finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
