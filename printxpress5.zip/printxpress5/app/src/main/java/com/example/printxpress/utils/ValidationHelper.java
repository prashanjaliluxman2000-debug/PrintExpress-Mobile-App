package com.example.printxpress.utils;

import android.util.Patterns;

public class ValidationHelper {

    public static boolean isValidEmail(
            String email) {
        return email != null &&
                !email.trim().isEmpty() &&
                Patterns.EMAIL_ADDRESS
                        .matcher(email).matches();
    }

    public static boolean isValidPhone(
            String phone) {
        return phone != null &&
                phone.matches("^[0-9]{10,15}$");
    }

    public static boolean isValidPassword(
            String password) {
        return password != null &&
                password.length() >= 6 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*[0-9].*");
    }

    public static boolean isValidName(String name) {
        return name != null &&
                name.trim().length() >= 2;
    }

    public static boolean isNotEmpty(String text) {
        return text != null &&
                !text.trim().isEmpty();
    }

    public static boolean isValidQuantity(
            String qty) {
        try {
            int q = Integer.parseInt(qty);
            return q >= 1 && q <= 10000;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
