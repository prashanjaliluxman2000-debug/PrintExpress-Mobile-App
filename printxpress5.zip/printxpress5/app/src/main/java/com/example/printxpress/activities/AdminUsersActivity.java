package com.example.printxpress.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.database.DBHelper;
import java.util.ArrayList;
import java.util.List;

public class AdminUsersActivity
        extends AppCompatActivity {

    private RecyclerView rv;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_admin_users);

        dbHelper = DBHelper.getInstance(this);
        rv = findViewById(R.id.rvAdminUsers);
        rv.setLayoutManager(
                new LinearLayoutManager(this));
        load();
    }

    private void load() {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_USERS +
                        " WHERE " + DBHelper.U_IS_ADMIN +
                        "=0 ORDER BY " +
                        DBHelper.U_CREATED + " DESC", null);

        List<String[]> list = new ArrayList<>();
        while (c.moveToNext()) {
            list.add(new String[]{
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.U_NAME)),
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.U_EMAIL)),
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.U_PHONE)),
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.U_CREATED))
            });
        }
        c.close();

        rv.setAdapter(new RecyclerView.Adapter<
                RecyclerView.ViewHolder>() {

            @NonNull @Override
            public RecyclerView.ViewHolder
            onCreateViewHolder(
                    @NonNull ViewGroup parent,
                    int viewType) {
                View v = LayoutInflater.from(
                                parent.getContext())
                        .inflate(
                                R.layout.item_admin_user,
                                parent, false);
                return new RecyclerView.ViewHolder(
                        v) {};
            }

            @Override
            public void onBindViewHolder(
                    @NonNull RecyclerView.ViewHolder
                            h, int pos) {
                String[] u = list.get(pos);
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminUserName))
                        .setText(u[0]);
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminUserEmail))
                        .setText(u[1]);
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminUserPhone))
                        .setText(u[2]);
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminUserDate))
                        .setText(u[3] != null &&
                                u[3].length() >= 10 ?
                                u[3].substring(0, 10) : "");
            }

            @Override
            public int getItemCount() {
                return list.size();
            }
        });
    }
}
