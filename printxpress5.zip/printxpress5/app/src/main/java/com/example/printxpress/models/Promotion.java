package com.example.printxpress.models;

public class Promotion {
    private int promoID;
    private String title;
    private String description;
    private int discountPercent;
    private String startDate;
    private String endDate;

    public Promotion() {}

    public int getPromoID() { return promoID; }
    public void setPromoID(int v) { promoID = v; }

    public String getTitle() { return title; }
    public void setTitle(String v) { title = v; }

    public String getDescription() {
        return description; }
    public void setDescription(String v) {
        description = v; }

    public int getDiscountPercent() {
        return discountPercent; }
    public void setDiscountPercent(int v) {
        discountPercent = v; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String v) {
        startDate = v; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String v) { endDate = v; }
}
