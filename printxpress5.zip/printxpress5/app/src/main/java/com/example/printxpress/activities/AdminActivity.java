package com.example.printxpress.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;
import com.example.printxpress.database.DBHelper;
import com.example.printxpress.utils.SessionManager;

public class AdminActivity extends AppCompatActivity {

    private TextView tvWelcome, tvOrders,
            tvUsers, tvProducts;
    private LinearLayout btnOrders, btnProducts,
            btnUsers, btnLogout;
    private DBHelper dbHelper;
    private SessionManager session;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        session = new SessionManager(this);
        dbHelper = DBHelper.getInstance(this);

        if (!session.isAdmin()) {
            startActivity(new Intent(this,
                    LoginActivity.class));
            finish();
            return;
        }

        tvWelcome = findViewById(
                R.id.tvAdminWelcome);
        tvOrders = findViewById(R.id.tvTotalOrders);
        tvUsers = findViewById(R.id.tvTotalUsers);
        tvProducts = findViewById(
                R.id.tvTotalProducts);
        btnOrders = findViewById(
                R.id.btnManageOrders);
        btnProducts = findViewById(
                R.id.btnManageProducts);
        btnUsers = findViewById(R.id.btnViewUsers);
        btnLogout = findViewById(
                R.id.btnAdminLogout);

        tvWelcome.setText("Welcome, " +
                session.getUserName());

        loadStats();

        btnOrders.setOnClickListener(v ->
                startActivity(new Intent(this,
                        AdminOrdersActivity.class)));
        btnProducts.setOnClickListener(v ->
                startActivity(new Intent(this,
                        AdminProductsActivity.class)));
        btnUsers.setOnClickListener(v ->
                startActivity(new Intent(this,
                        AdminUsersActivity.class)));
        btnLogout.setOnClickListener(v -> {
            new androidx.appcompat.app.AlertDialog
                    .Builder(this)
                    .setTitle("Logout")
                    .setMessage("Are you sure?")
                    .setPositiveButton("Logout",
                            (d, w) -> {
                                session.clearSession();
                                startActivity(new Intent(this,
                                        LoginActivity.class));
                                finish();
                            })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    private void loadStats() {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();

        Cursor c1 = db.rawQuery(
                "SELECT COUNT(*) FROM " +
                        DBHelper.TABLE_ORDERS, null);
        if (c1.moveToFirst())
            tvOrders.setText(
                    String.valueOf(c1.getInt(0)));
        c1.close();

        Cursor c2 = db.rawQuery(
                "SELECT COUNT(*) FROM " +
                        DBHelper.TABLE_USERS +
                        " WHERE " + DBHelper.U_IS_ADMIN +
                        "=0", null);
        if (c2.moveToFirst())
            tvUsers.setText(
                    String.valueOf(c2.getInt(0)));
        c2.close();

        Cursor c3 = db.rawQuery(
                "SELECT COUNT(*) FROM " +
                        DBHelper.TABLE_PRODUCTS, null);
        if (c3.moveToFirst())
            tvProducts.setText(
                    String.valueOf(c3.getInt(0)));
        c3.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStats();
    }
}
