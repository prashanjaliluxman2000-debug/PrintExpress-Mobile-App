package com.example.printxpress.models;

public class Address {
    private int addressID;
    private int userID;
    private String addressLine;
    private String city;
    private boolean isDefault;

    public Address() {}

    public int getAddressID() { return addressID; }
    public void setAddressID(int v) { addressID = v; }

    public int getUserID() { return userID; }
    public void setUserID(int v) { userID = v; }

    public String getAddressLine() {
        return addressLine; }
    public void setAddressLine(String v) {
        addressLine = v; }

    public String getCity() { return city; }
    public void setCity(String v) { city = v; }

    public boolean isDefault() { return isDefault; }
    public void setDefault(boolean v) {
        isDefault = v; }
}
