package com.example.printxpress.models;

public class Order {
    private int orderID;
    private int userID;
    private String orderDate;
    private String status;
    private String deliveryType;
    private String deliveryAddress;
    private double totalAmount;
    private String notes;
    private String filePath;
    private String customText;
    private String paperType;
    private int quantity;
    private int productID;

    public Order() {}

    public int getOrderID() { return orderID; }
    public void setOrderID(int v) { orderID = v; }

    public int getUserID() { return userID; }
    public void setUserID(int v) { userID = v; }

    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String v) {
        orderDate = v; }

    public String getStatus() { return status; }
    public void setStatus(String v) { status = v; }

    public String getDeliveryType() {
        return deliveryType; }
    public void setDeliveryType(String v) {
        deliveryType = v; }

    public String getDeliveryAddress() {
        return deliveryAddress; }
    public void setDeliveryAddress(String v) {
        deliveryAddress = v; }

    public double getTotalAmount() {
        return totalAmount; }
    public void setTotalAmount(double v) {
        totalAmount = v; }

    public String getNotes() { return notes; }
    public void setNotes(String v) { notes = v; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String v) { filePath = v; }

    public String getCustomText() { return customText; }
    public void setCustomText(String v) {
        customText = v; }

    public String getPaperType() { return paperType; }
    public void setPaperType(String v) {
        paperType = v; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int v) { quantity = v; }

    public int getProductID() { return productID; }
    public void setProductID(int v) { productID = v; }
}
