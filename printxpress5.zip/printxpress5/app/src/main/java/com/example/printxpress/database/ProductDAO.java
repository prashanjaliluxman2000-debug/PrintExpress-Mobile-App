package com.example.printxpress.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.printxpress.models.Category;
import com.example.printxpress.models.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    private DBHelper dbHelper;

    public ProductDAO(Context context) {
        dbHelper = DBHelper.getInstance(context);
    }

    public List<Category> getAllCategories() {
        List<Category> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_CATEGORIES, null);
        while (c.moveToNext()) {
            Category cat = new Category();
            cat.setCategoryID(c.getInt(
                    c.getColumnIndexOrThrow(
                            DBHelper.C_ID)));
            cat.setCategoryName(c.getString(
                    c.getColumnIndexOrThrow(
                            DBHelper.C_NAME)));
            list.add(cat);
        }
        c.close();
        return list;
    }

    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_PRODUCTS, null);
        while (c.moveToNext()) {
            list.add(mapProduct(c));
        }
        c.close();
        return list;
    }

    public List<Product> getProductsByCategory(
            int categoryID) {
        List<Product> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_PRODUCTS +
                        " WHERE " + DBHelper.P_CAT_ID +
                        "=?",
                new String[]{
                        String.valueOf(categoryID)});
        while (c.moveToNext()) {
            list.add(mapProduct(c));
        }
        c.close();
        return list;
    }

    public Product getProductByID(int productID) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_PRODUCTS +
                        " WHERE " + DBHelper.P_ID + "=?",
                new String[]{
                        String.valueOf(productID)});
        Product p = null;
        if (c.moveToFirst()) p = mapProduct(c);
        c.close();
        return p;
    }

    public long addProduct(Product product) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.P_CAT_ID,
                product.getCategoryID());
        cv.put(DBHelper.P_NAME, product.getName());
        cv.put(DBHelper.P_DESC,
                product.getDescription());
        cv.put(DBHelper.P_MATERIAL,
                product.getMaterial());
        cv.put(DBHelper.P_SIZE, product.getSize());
        cv.put(DBHelper.P_PRICE, product.getPrice());
        return db.insert(
                DBHelper.TABLE_PRODUCTS, null, cv);
    }

    public boolean updateProduct(Product product) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.P_NAME, product.getName());
        cv.put(DBHelper.P_DESC,
                product.getDescription());
        cv.put(DBHelper.P_MATERIAL,
                product.getMaterial());
        cv.put(DBHelper.P_SIZE, product.getSize());
        cv.put(DBHelper.P_PRICE, product.getPrice());
        int rows = db.update(
                DBHelper.TABLE_PRODUCTS, cv,
                DBHelper.P_ID + "=?",
                new String[]{String.valueOf(
                        product.getProductID())});
        return rows > 0;
    }

    public boolean deleteProduct(int productID) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        int rows = db.delete(
                DBHelper.TABLE_PRODUCTS,
                DBHelper.P_ID + "=?",
                new String[]{
                        String.valueOf(productID)});
        return rows > 0;
    }

    private Product mapProduct(Cursor c) {
        Product p = new Product();
        p.setProductID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.P_ID)));
        p.setCategoryID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.P_CAT_ID)));
        p.setName(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.P_NAME)));
        p.setDescription(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.P_DESC)));
        p.setMaterial(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.P_MATERIAL)));
        p.setSize(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.P_SIZE)));
        p.setPrice(c.getDouble(
                c.getColumnIndexOrThrow(
                        DBHelper.P_PRICE)));
        return p;
    }
}
