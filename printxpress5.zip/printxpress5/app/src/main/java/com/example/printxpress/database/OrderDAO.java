package com.example.printxpress.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.printxpress.models.Order;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    private DBHelper dbHelper;

    public OrderDAO(Context context) {
        dbHelper = DBHelper.getInstance(context);
    }

    public long placeOrder(Order order) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.O_USER_ID,
                order.getUserID());
        cv.put(DBHelper.O_PRODUCT_ID,
                order.getProductID());
        cv.put(DBHelper.O_STATUS,
                order.getStatus());
        cv.put(DBHelper.O_DELIVERY,
                order.getDeliveryType());
        cv.put(DBHelper.O_ADDRESS,
                order.getDeliveryAddress());
        cv.put(DBHelper.O_TOTAL,
                order.getTotalAmount());
        cv.put(DBHelper.O_NOTES, order.getNotes());
        cv.put(DBHelper.O_FILE, order.getFilePath());
        cv.put(DBHelper.O_CUSTOM_TEXT,
                order.getCustomText());
        cv.put(DBHelper.O_PAPER,
                order.getPaperType());
        cv.put(DBHelper.O_QTY, order.getQuantity());
        return db.insert(
                DBHelper.TABLE_ORDERS, null, cv);
    }

    public List<Order> getOrdersByUser(int userID) {
        List<Order> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_ORDERS +
                        " WHERE " + DBHelper.O_USER_ID +
                        "=? ORDER BY " +
                        DBHelper.O_DATE + " DESC",
                new String[]{
                        String.valueOf(userID)});
        while (c.moveToNext()) {
            list.add(mapOrder(c));
        }
        c.close();
        return list;
    }

    public List<Order> getAllOrders() {
        List<Order> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_ORDERS +
                        " ORDER BY " +
                        DBHelper.O_DATE + " DESC", null);
        while (c.moveToNext()) {
            list.add(mapOrder(c));
        }
        c.close();
        return list;
    }

    public Order getOrderByID(int orderID) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_ORDERS +
                        " WHERE " + DBHelper.O_ID + "=?",
                new String[]{
                        String.valueOf(orderID)});
        Order order = null;
        if (c.moveToFirst()) order = mapOrder(c);
        c.close();
        return order;
    }

    public boolean cancelOrder(int orderID) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.O_STATUS, "Cancelled");
        int rows = db.update(
                DBHelper.TABLE_ORDERS, cv,
                DBHelper.O_ID + "=? AND " +
                        DBHelper.O_STATUS + "=?",
                new String[]{
                        String.valueOf(orderID),
                        "Processing"});
        return rows > 0;
    }

    public boolean updateStatus(int orderID,
                                String status) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.O_STATUS, status);
        int rows = db.update(
                DBHelper.TABLE_ORDERS, cv,
                DBHelper.O_ID + "=?",
                new String[]{
                        String.valueOf(orderID)});
        return rows > 0;
    }

    private Order mapOrder(Cursor c) {
        Order o = new Order();
        o.setOrderID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.O_ID)));
        o.setUserID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.O_USER_ID)));
        o.setProductID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.O_PRODUCT_ID)));
        o.setOrderDate(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_DATE)));
        o.setStatus(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_STATUS)));
        o.setDeliveryType(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_DELIVERY)));
        o.setDeliveryAddress(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_ADDRESS)));
        o.setTotalAmount(c.getDouble(
                c.getColumnIndexOrThrow(
                        DBHelper.O_TOTAL)));
        o.setNotes(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_NOTES)));
        o.setFilePath(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_FILE)));
        o.setCustomText(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_CUSTOM_TEXT)));
        o.setPaperType(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.O_PAPER)));
        o.setQuantity(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.O_QTY)));
        return o;
    }
}