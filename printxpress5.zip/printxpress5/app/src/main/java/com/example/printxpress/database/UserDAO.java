package com.example.printxpress.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.printxpress.models.User;

public class UserDAO {

    private DBHelper dbHelper;

    public UserDAO(Context context) {
        dbHelper = DBHelper.getInstance(context);
    }

    public long registerUser(User user) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.U_NAME, user.getName());
        cv.put(DBHelper.U_EMAIL, user.getEmail());
        cv.put(DBHelper.U_PHONE, user.getPhone());
        cv.put(DBHelper.U_PASSWORD,
                DBHelper.hashPassword(
                        user.getPassword()));
        cv.put(DBHelper.U_IS_ADMIN, 0);
        return db.insert(
                DBHelper.TABLE_USERS, null, cv);
    }

    public User loginUser(String emailOrPhone,
                          String password) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        String hashed =
                DBHelper.hashPassword(password);
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_USERS +
                        " WHERE (" + DBHelper.U_EMAIL +
                        "=? OR " + DBHelper.U_PHONE +
                        "=?) AND " +
                        DBHelper.U_PASSWORD + "=?",
                new String[]{emailOrPhone,
                        emailOrPhone, hashed});
        User user = null;
        if (c.moveToFirst()) user = mapUser(c);
        c.close();
        return user;
    }

    public boolean isEmailExists(String email) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT " + DBHelper.U_ID +
                        " FROM " + DBHelper.TABLE_USERS +
                        " WHERE " + DBHelper.U_EMAIL + "=?",
                new String[]{email});
        boolean ex = c.getCount() > 0;
        c.close();
        return ex;
    }

    public boolean isPhoneExists(String phone) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT " + DBHelper.U_ID +
                        " FROM " + DBHelper.TABLE_USERS +
                        " WHERE " + DBHelper.U_PHONE + "=?",
                new String[]{phone});
        boolean ex = c.getCount() > 0;
        c.close();
        return ex;
    }

    public User getUserByID(int userID) {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_USERS +
                        " WHERE " + DBHelper.U_ID + "=?",
                new String[]{
                        String.valueOf(userID)});
        User user = null;
        if (c.moveToFirst()) user = mapUser(c);
        c.close();
        return user;
    }

    public boolean updateUser(User user) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.U_NAME, user.getName());
        cv.put(DBHelper.U_PHONE, user.getPhone());
        int rows = db.update(DBHelper.TABLE_USERS,
                cv, DBHelper.U_ID + "=?",
                new String[]{String.valueOf(
                        user.getUserID())});
        return rows > 0;
    }

    public boolean updatePassword(int userID,
                                  String newPwd) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.U_PASSWORD,
                DBHelper.hashPassword(newPwd));
        int rows = db.update(DBHelper.TABLE_USERS,
                cv, DBHelper.U_ID + "=?",
                new String[]{
                        String.valueOf(userID)});
        return rows > 0;
    }

    private User mapUser(Cursor c) {
        User u = new User();
        u.setUserID(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.U_ID)));
        u.setName(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.U_NAME)));
        u.setEmail(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.U_EMAIL)));
        u.setPhone(c.getString(
                c.getColumnIndexOrThrow(
                        DBHelper.U_PHONE)));
        u.setAdmin(c.getInt(
                c.getColumnIndexOrThrow(
                        DBHelper.U_IS_ADMIN)) == 1);
        return u;
    }
}