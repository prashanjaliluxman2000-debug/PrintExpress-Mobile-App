package com.example.printxpress.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.printxpress.constants.AppConstants;

public class SessionManager {

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(
                AppConstants.PREF_NAME,
                Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveSession(int userID,
                            String name, String email,
                            boolean isAdmin) {
        editor.putInt(AppConstants.KEY_USER_ID,
                userID);
        editor.putString(AppConstants.KEY_USER_NAME,
                name);
        editor.putString(AppConstants.KEY_USER_EMAIL,
                email);
        editor.putBoolean(
                AppConstants.KEY_IS_LOGGED_IN, true);
        editor.putBoolean(AppConstants.KEY_IS_ADMIN,
                isAdmin);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(
                AppConstants.KEY_IS_LOGGED_IN, false);
    }

    public boolean isAdmin() {
        return prefs.getBoolean(
                AppConstants.KEY_IS_ADMIN, false);
    }

    public int getUserID() {
        return prefs.getInt(
                AppConstants.KEY_USER_ID, -1);
    }

    public String getUserName() {
        return prefs.getString(
                AppConstants.KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return prefs.getString(
                AppConstants.KEY_USER_EMAIL, "");
    }

    public void clearSession() {
        editor.clear();
        editor.apply();
    }
}