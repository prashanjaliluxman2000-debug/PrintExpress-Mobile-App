package com.example.printxpress.fragments;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.example.printxpress.R;
import com.example.printxpress.activities.MainActivity;
import com.example.printxpress.database.DBHelper;
import java.util.ArrayList;
import java.util.List;

public class NotificationsFragment extends Fragment {

    private RecyclerView rvNotif;
    private LinearLayout layoutEmpty;
    private MaterialButton btnMarkAll;
    private DBHelper dbHelper;
    private NotifAdapter adapter;

    @Nullable @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(
                R.layout.fragment_notifications,
                container, false);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = DBHelper.getInstance(requireContext());
        rvNotif = view.findViewById(
                R.id.rvNotifications);
        layoutEmpty = view.findViewById(
                R.id.layoutEmpty);
        btnMarkAll = view.findViewById(
                R.id.btnMarkAllRead);

        rvNotif.setLayoutManager(
                new LinearLayoutManager(
                        getContext()));
        adapter = new NotifAdapter(new ArrayList<>());
        rvNotif.setAdapter(adapter);

        btnMarkAll.setOnClickListener(v -> {
            markAllRead();
            load();
        });
        load();
    }

    private void load() {
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_NOTIFICATIONS +
                        " WHERE " + DBHelper.N_USER_ID +
                        "=? ORDER BY " +
                        DBHelper.N_DATE + " DESC",
                new String[]{String.valueOf(
                        MainActivity.loggedInUserID)});
        List<String[]> list = new ArrayList<>();
        while (c.moveToNext()) {
            list.add(new String[]{
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.N_TITLE)),
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.N_MESSAGE)),
                    c.getString(c.getColumnIndexOrThrow(
                            DBHelper.N_DATE)),
                    String.valueOf(c.getInt(
                            c.getColumnIndexOrThrow(
                                    DBHelper.N_READ)))
            });
        }
        c.close();
        adapter.updateList(list);

        boolean empty = list.isEmpty();
        rvNotif.setVisibility(
                empty ? View.GONE : View.VISIBLE);
        layoutEmpty.setVisibility(
                empty ? View.VISIBLE : View.GONE);
        btnMarkAll.setVisibility(
                empty ? View.GONE : View.VISIBLE);
    }

    private void markAllRead() {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.N_READ, 1);
        db.update(DBHelper.TABLE_NOTIFICATIONS,
                cv, DBHelper.N_USER_ID + "=?",
                new String[]{String.valueOf(
                        MainActivity.loggedInUserID)});
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    class NotifAdapter extends RecyclerView.Adapter<
            NotifAdapter.VH> {

        private List<String[]> list;

        NotifAdapter(List<String[]> list) {
            this.list = list;
        }

        void updateList(List<String[]> newList) {
            this.list = newList;
            notifyDataSetChanged();
        }

        @NonNull @Override
        public VH onCreateViewHolder(
                @NonNull ViewGroup parent,
                int viewType) {
            View v = LayoutInflater.from(
                    parent.getContext()).inflate(
                    R.layout.item_notification_card,
                    parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(
                @NonNull VH holder, int position) {
            String[] n = list.get(position);
            holder.tvMessage.setText(n[1]);
            holder.tvTime.setText(
                    n[2] != null &&
                            n[2].length() >= 10 ?
                            n[2].substring(0, 10) : "");
            holder.dotUnread.setVisibility(
                    "0".equals(n[3]) ?
                            View.VISIBLE : View.GONE);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView tvMessage, tvTime;
            View dotUnread;

            VH(View v) {
                super(v);
                tvMessage = v.findViewById(
                        R.id.tvNotifMessage);
                tvTime = v.findViewById(
                        R.id.tvNotifTime);
                dotUnread = v.findViewById(
                        R.id.dotUnread);
            }
        }
    }
}
