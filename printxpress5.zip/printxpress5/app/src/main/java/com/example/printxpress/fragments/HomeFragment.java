package com.example.printxpress.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.activities.MainActivity;
import com.example.printxpress.activities.PlaceOrderActivity;
import com.example.printxpress.activities.SupportActivity;
import com.example.printxpress.adapters.CategoryAdapter;
import com.example.printxpress.adapters.ProductAdapter;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.ProductDAO;
import com.example.printxpress.models.Category;
import com.example.printxpress.models.Product;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private TextView tvGreeting, tvViewAll;
    private RecyclerView rvCategories, rvProducts;
    private ProductDAO productDAO;
    private ProductAdapter productAdapter;
    private List<Product> allProducts =
            new ArrayList<>();

    @Nullable @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(
                R.layout.fragment_home,
                container, false);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        productDAO = new ProductDAO(
                requireContext());

        initViews(view);
        setGreeting();
        loadCategories();
        loadProducts();
    }

    private void initViews(View view) {
        tvGreeting = view.findViewById(
                R.id.tvGreeting);
        tvViewAll = view.findViewById(
                R.id.tvViewAll);
        rvCategories = view.findViewById(
                R.id.rvCategories);
        rvProducts = view.findViewById(
                R.id.rvProducts);

        view.findViewById(R.id.ivUserProfile).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).loadFragment(new ProfileFragment());
            }
        });

        view.findViewById(R.id.btnInfo).setOnClickListener(v -> {
            startActivity(new Intent(getContext(), SupportActivity.class));
        });

        view.findViewById(R.id.btnBrowseHero).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).navigateToProducts();
            }
        });

        tvViewAll.setOnClickListener(v -> {
            if (getActivity() instanceof
                    MainActivity) {
                ((MainActivity) getActivity())
                        .navigateToProducts();
            }
        });
    }

    private void setGreeting() {
        if (MainActivity.loggedInUserName != null) {
            String name = MainActivity.loggedInUserName;
            if (!name.isEmpty()) {
                name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
            }
            tvGreeting.setText(getString(R.string.welcome_back, name));
        }
    }

    private void loadCategories() {
        List<Category> cats =
                productDAO.getAllCategories();
        rvCategories.setLayoutManager(
                new LinearLayoutManager(getContext(),
                        LinearLayoutManager.HORIZONTAL,
                        false));
        rvCategories.setAdapter(
                new CategoryAdapter(cats,
                        categoryID -> {
                            if (getActivity() instanceof
                                    MainActivity) {
                                ((MainActivity) getActivity())
                                        .navigateToProductsByCategory(
                                                categoryID);
                            }
                        }));
    }

    private void loadProducts() {
        allProducts = productDAO.getAllProducts();
        rvProducts.setLayoutManager(
                new LinearLayoutManager(
                        getContext()));
        productAdapter = new ProductAdapter(
                allProducts, product -> {
            Intent intent = new Intent(
                    getContext(),
                    PlaceOrderActivity.class);
            intent.putExtra(
                    AppConstants.KEY_PRODUCT_ID,
                    product.getProductID());
            startActivity(intent);
        });
        rvProducts.setAdapter(productAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProducts();
    }
}
