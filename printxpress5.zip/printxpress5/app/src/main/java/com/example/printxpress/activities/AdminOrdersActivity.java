package com.example.printxpress.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.example.printxpress.R;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.DBHelper;
import com.example.printxpress.database.OrderDAO;
import com.example.printxpress.utils.NotificationHelper;
import java.util.ArrayList;
import java.util.List;

public class AdminOrdersActivity extends AppCompatActivity {

    private RecyclerView rv;
    private SwipeRefreshLayout swipeRefreshLayout;
    private DBHelper dbHelper;
    private OrderDAO orderDAO;
    private NotificationHelper notifHelper;
    private List<String[]> orderList = new ArrayList<>();
    private OrdersAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_orders);

        dbHelper = DBHelper.getInstance(this);
        orderDAO = new OrderDAO(this);
        notifHelper = new NotificationHelper(this);

        rv = findViewById(R.id.rvAdminOrders);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new OrdersAdapter();
        rv.setAdapter(adapter);

        swipeRefreshLayout.setOnRefreshListener(this::load);
        load();
    }

    private void load() {
        swipeRefreshLayout.setRefreshing(true);
        new Thread(() -> {
            final List<String[]> newList = new ArrayList<>();
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor c = db.rawQuery(
                    "SELECT o.*, u." + DBHelper.U_NAME + " as cname FROM " +
                            DBHelper.TABLE_ORDERS + " o LEFT JOIN " +
                            DBHelper.TABLE_USERS + " u ON o." + DBHelper.O_USER_ID +
                            "=u." + DBHelper.U_ID + " ORDER BY o." +
                            DBHelper.O_DATE + " DESC", null);

            while (c.moveToNext()) {
                String orderID = c.getString(c.getColumnIndexOrThrow(DBHelper.O_ID));
                String status = c.getString(c.getColumnIndexOrThrow(DBHelper.O_STATUS));
                String total = c.getString(c.getColumnIndexOrThrow(DBHelper.O_TOTAL));
                String customer = c.getString(c.getColumnIndexOrThrow("cname"));
                String date = c.getString(c.getColumnIndexOrThrow(DBHelper.O_DATE));
                String delivery = c.getString(c.getColumnIndexOrThrow(DBHelper.O_DELIVERY));
                String userID = c.getString(c.getColumnIndexOrThrow(DBHelper.O_USER_ID));
                String filePath = c.getString(c.getColumnIndexOrThrow(DBHelper.O_FILE));

                newList.add(new String[]{
                        orderID, status, total, customer, date, delivery, userID, filePath
                });
            }
            c.close();

            runOnUiThread(() -> {
                orderList.clear();
                orderList.addAll(newList);
                adapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            });
        }).start();
    }

    private void updateStatus(String orderID, String userID, String newStatus) {
        if (orderDAO.updateStatus(Integer.parseInt(orderID), newStatus)) {
            notifHelper.orderStatusUpdated(
                    Integer.parseInt(orderID),
                    Integer.parseInt(userID),
                    newStatus);
            Toast.makeText(this, "Order #" + orderID + " updated to: " + newStatus, Toast.LENGTH_SHORT).show();
            load();
        } else {
            Toast.makeText(this, "Update failed!", Toast.LENGTH_SHORT).show();
        }
    }

    class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_order, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            final String[] o = orderList.get(position);

            holder.tvOrderID.setText("#" + String.format("%05d", Integer.parseInt(o[0])));
            holder.tvStatus.setText(o[1]);
            holder.tvTotal.setText("LKR " + String.format("%.2f", Double.parseDouble(o[2])));
            holder.tvCustomer.setText(o[3] != null ? o[3] : "Unknown");
            holder.tvDate.setText(o[4] != null && o[4].length() >= 10 ? o[4].substring(0, 10) : "");
            holder.tvDelivery.setText(o[5] != null ? o[5] : "");

            // Show icon if there's a design file
            if (o.length > 7 && o[7] != null && !o[7].isEmpty()) {
                holder.ivDesignIcon.setVisibility(View.VISIBLE);
                holder.ivDesignIcon.setOnClickListener(v -> showDesignDialog(o[7]));
            } else {
                holder.ivDesignIcon.setVisibility(View.GONE);
            }

            // Status backgrounds
            if (AppConstants.STATUS_PROCESSING.equals(o[1])) {
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_processing);
            } else if (AppConstants.STATUS_PRINTING.equals(o[1])) {
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_printing);
            } else if (AppConstants.STATUS_READY.equals(o[1])) {
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_ready);
            } else if (AppConstants.STATUS_DELIVERED.equals(o[1])) {
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_delivered);
            } else if (AppConstants.STATUS_CANCELLED.equals(o[1])) {
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
            }

            // Click listener for the whole card to change status
            holder.itemView.setOnClickListener(v -> showStatusDialog(o));
            
            // Explicit click for the refresh button
            holder.btnRefresh.setOnClickListener(v -> load());
        }

        @Override
        public int getItemCount() {
            return orderList.size();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView tvOrderID, tvStatus, tvTotal, tvCustomer, tvDate, tvDelivery;
            android.widget.ImageView ivDesignIcon;
            View btnRefresh;

            VH(View v) {
                super(v);
                tvOrderID = v.findViewById(R.id.tvAdminOrderID);
                tvStatus = v.findViewById(R.id.tvAdminOrderStatus);
                tvTotal = v.findViewById(R.id.tvAdminOrderTotal);
                tvCustomer = v.findViewById(R.id.tvAdminCustomer);
                tvDate = v.findViewById(R.id.tvAdminOrderDate);
                tvDelivery = v.findViewById(R.id.tvAdminOrderDelivery);
                ivDesignIcon = v.findViewById(R.id.ivAdminDesignIcon);
                btnRefresh = v.findViewById(R.id.btnRefreshStatus);
            }
        }
    }

    private void showDesignDialog(String path) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_view_design, null);
        android.widget.ImageView iv = view.findViewById(R.id.ivFullDesign);
        
        try {
            if (path.startsWith("/")) {
                iv.setImageURI(android.net.Uri.fromFile(new java.io.File(path)));
            } else {
                iv.setImageURI(android.net.Uri.parse(path));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error loading design", Toast.LENGTH_SHORT).show();
        }

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Customer Design")
                .setView(view)
                .setPositiveButton("Close", null)
                .show();
    }

    private void showStatusDialog(String[] order) {
        String[] statuses = {
                AppConstants.STATUS_PROCESSING,
                AppConstants.STATUS_PRINTING,
                AppConstants.STATUS_READY,
                AppConstants.STATUS_DELIVERED,
                AppConstants.STATUS_CANCELLED
        };

        // Note: setMessage() often hides setItems() in many Android versions.
        // We move essential info to the title to ensure the status list is visible.
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Update Status: #" + String.format("%05d", Integer.parseInt(order[0])))
                .setItems(statuses, (d, which) -> {
                    updateStatus(order[0], order[6], statuses[which]);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }
}
