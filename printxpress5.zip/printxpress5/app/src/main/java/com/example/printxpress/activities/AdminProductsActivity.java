package com.example.printxpress.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.database.ProductDAO;
import com.example.printxpress.models.Product;
import java.util.List;

public class AdminProductsActivity
        extends AppCompatActivity {

    private RecyclerView rv;
    private ProductDAO productDAO;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_admin_products);

        productDAO = new ProductDAO(this);
        rv = findViewById(R.id.rvAdminProducts);
        rv.setLayoutManager(
                new LinearLayoutManager(this));

        // Add product button
        findViewById(R.id.btnAddProduct)
                .setOnClickListener(v ->
                        showAddDialog());
        load();
    }

    private void load() {
        List<Product> products =
                productDAO.getAllProducts();
        rv.setAdapter(new RecyclerView.Adapter<
                RecyclerView.ViewHolder>() {

            @NonNull @Override
            public RecyclerView.ViewHolder
            onCreateViewHolder(
                    @NonNull ViewGroup parent,
                    int viewType) {
                View v = LayoutInflater.from(
                                parent.getContext())
                        .inflate(
                                R.layout.item_admin_product,
                                parent, false);
                return new RecyclerView.ViewHolder(
                        v) {};
            }

            @Override
            public void onBindViewHolder(
                    @NonNull RecyclerView.ViewHolder
                            h, int pos) {
                Product p = products.get(pos);
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminProductName))
                        .setText(p.getName());
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminProductPrice))
                        .setText(String.format(
                                "LKR %.2f", p.getPrice()));
                ((TextView) h.itemView.findViewById(
                        R.id.tvAdminProductMaterial))
                        .setText(p.getMaterial() +
                                " | " + p.getSize());

                // Edit
                h.itemView.setOnClickListener(v ->
                        showEditDialog(p));

                // Delete
                h.itemView.setOnLongClickListener(
                        v -> {
                            new androidx.appcompat.app
                                    .AlertDialog.Builder(
                                    AdminProductsActivity
                                            .this)
                                    .setTitle("Delete Product")
                                    .setMessage("Delete " +
                                            p.getName() + "?")
                                    .setPositiveButton("Delete",
                                            (d, w) -> {
                                                productDAO.deleteProduct(
                                                        p.getProductID());
                                                Toast.makeText(
                                                                AdminProductsActivity
                                                                        .this,
                                                                "Deleted!",
                                                                Toast.LENGTH_SHORT)
                                                        .show();
                                                load();
                                            })
                                    .setNegativeButton(
                                            "Cancel", null)
                                    .show();
                            return true;
                        });
            }

            @Override
            public int getItemCount() {
                return products.size();
            }
        });
    }

    private void showAddDialog() {
        View dv = LayoutInflater.from(this)
                .inflate(
                        R.layout.dialog_add_product, null);
        EditText etName = dv.findViewById(
                R.id.etProductName);
        EditText etDesc = dv.findViewById(
                R.id.etProductDesc);
        EditText etMaterial = dv.findViewById(
                R.id.etProductMaterial);
        EditText etSize = dv.findViewById(
                R.id.etProductSize);
        EditText etPrice = dv.findViewById(
                R.id.etProductPrice);

        new androidx.appcompat.app.AlertDialog
                .Builder(this)
                .setTitle("Add Product")
                .setView(dv)
                .setPositiveButton("Add", (d, w) -> {
                    String name = etName.getText()
                            .toString().trim();
                    String desc = etDesc.getText()
                            .toString().trim();
                    String material = etMaterial
                            .getText().toString().trim();
                    String size = etSize.getText()
                            .toString().trim();
                    String priceStr = etPrice.getText()
                            .toString().trim();

                    if (name.isEmpty() ||
                            priceStr.isEmpty()) {
                        Toast.makeText(this,
                                "Name and price required!",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Product p = new Product();
                    p.setName(name);
                    p.setDescription(desc);
                    p.setMaterial(material);
                    p.setSize(size);
                    p.setCategoryID(1);
                    try {
                        p.setPrice(Double.parseDouble(
                                priceStr));
                    } catch (Exception e) {
                        p.setPrice(0);
                    }

                    productDAO.addProduct(p);
                    Toast.makeText(this,
                            "Product added!",
                            Toast.LENGTH_SHORT).show();
                    load();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDialog(Product product) {
        View dv = LayoutInflater.from(this)
                .inflate(
                        R.layout.dialog_add_product, null);
        EditText etName = dv.findViewById(
                R.id.etProductName);
        EditText etDesc = dv.findViewById(
                R.id.etProductDesc);
        EditText etMaterial = dv.findViewById(
                R.id.etProductMaterial);
        EditText etSize = dv.findViewById(
                R.id.etProductSize);
        EditText etPrice = dv.findViewById(
                R.id.etProductPrice);

        etName.setText(product.getName());
        etDesc.setText(product.getDescription());
        etMaterial.setText(product.getMaterial());
        etSize.setText(product.getSize());
        etPrice.setText(String.valueOf(
                product.getPrice()));

        new androidx.appcompat.app.AlertDialog
                .Builder(this)
                .setTitle("Edit Product")
                .setView(dv)
                .setPositiveButton("Update", (d, w) -> {
                    product.setName(etName.getText()
                            .toString().trim());
                    product.setDescription(
                            etDesc.getText()
                                    .toString().trim());
                    product.setMaterial(
                            etMaterial.getText()
                                    .toString().trim());
                    product.setSize(etSize.getText()
                            .toString().trim());
                    try {
                        product.setPrice(
                                Double.parseDouble(
                                        etPrice.getText()
                                                .toString().trim()));
                    } catch (Exception ignored) {}

                    productDAO.updateProduct(product);
                    Toast.makeText(this,
                            "Updated!",
                            Toast.LENGTH_SHORT).show();
                    load();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
