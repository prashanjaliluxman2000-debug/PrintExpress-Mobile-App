package com.example.printxpress.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.example.printxpress.R;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.models.Order;
import java.util.List;

public class OrderAdapter extends
        RecyclerView.Adapter<OrderAdapter.VH> {

    public interface OnCancel {
        void onCancel(Order order);
    }

    public interface OnTrack {
        void onTrack(Order order);
    }

    private List<Order> list;
    private OnCancel cancelListener;
    private OnTrack trackListener;

    public OrderAdapter(List<Order> list,
                        OnCancel cancelListener,
                        OnTrack trackListener) {
        this.list = list;
        this.cancelListener = cancelListener;
        this.trackListener = trackListener;
    }

    public void updateList(List<Order> newList) {
        this.list = newList;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(
                parent.getContext()).inflate(
                R.layout.item_order_card,
                parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(
            @NonNull VH holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class VH extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvStatus,
                tvDate, tvDelivery, tvTotal;
        MaterialButton btnCancel, btnTrack;

        VH(View v) {
            super(v);
            tvOrderId = v.findViewById(
                    R.id.tvOrderId);
            tvStatus = v.findViewById(
                    R.id.tvOrderStatus);
            tvDate = v.findViewById(
                    R.id.tvOrderDate);
            tvDelivery = v.findViewById(
                    R.id.tvDeliveryType);
            tvTotal = v.findViewById(
                    R.id.tvOrderTotal);
            btnCancel = v.findViewById(
                    R.id.btnCancelOrder);
            btnTrack = v.findViewById(
                    R.id.btnTrackOrder);
        }

        void bind(Order o) {
            tvOrderId.setText("#" +
                    String.format("%05d",
                            o.getOrderID()));
            tvStatus.setText(o.getStatus());
            tvDate.setText(
                    o.getOrderDate() != null &&
                            o.getOrderDate().length() >= 10 ?
                            o.getOrderDate().substring(0, 10)
                            : "");
            tvDelivery.setText(o.getDeliveryType());
            tvTotal.setText(String.format(
                    "LKR %.2f", o.getTotalAmount()));

            // Update status background
            if (AppConstants.STATUS_PROCESSING.equals(o.getStatus())) {
                tvStatus.setBackgroundResource(R.drawable.bg_status_processing);
            } else if (AppConstants.STATUS_PRINTING.equals(o.getStatus())) {
                tvStatus.setBackgroundResource(R.drawable.bg_status_printing);
            } else if (AppConstants.STATUS_READY.equals(o.getStatus())) {
                tvStatus.setBackgroundResource(R.drawable.bg_status_ready);
            } else if (AppConstants.STATUS_DELIVERED.equals(o.getStatus())) {
                tvStatus.setBackgroundResource(R.drawable.bg_status_delivered);
            } else if (AppConstants.STATUS_CANCELLED.equals(o.getStatus())) {
                tvStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
            }

            if (AppConstants.STATUS_PROCESSING.equals(o.getStatus())) {
                btnCancel.setVisibility(View.VISIBLE);
                btnCancel.setOnClickListener(v ->
                        cancelListener.onCancel(o));
            } else {
                btnCancel.setVisibility(View.GONE);
            }

            btnTrack.setOnClickListener(v ->
                    trackListener.onTrack(o));
        }
    }
}
