package com.example.printxpress.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.OrderDAO;
import com.example.printxpress.database.ProductDAO;
import com.example.printxpress.models.Order;
import com.example.printxpress.models.Product;

public class OrderTrackingActivity
        extends AppCompatActivity  {

    private TextView tvOrderID, tvStatus,
            tvDate, tvDelivery, tvTotal,
            tvAddress, tvProduct, tvQty,
            tvPaper, tvCustomText,
            tvProgPlaced, tvProgProcessing, tvProgPrinting, tvProgReady, tvProgDelivered;
    private android.widget.ImageView ivTrackDesignPreview;
    private OrderDAO orderDAO;
    private ProductDAO productDAO;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(
                R.layout.activity_order_tracking);

        orderDAO = new OrderDAO(this);
        productDAO = new ProductDAO(this);

        tvOrderID = findViewById(R.id.tvTrackOrderID);
        tvStatus = findViewById(R.id.tvTrackStatus);
        tvDate = findViewById(R.id.tvTrackDate);
        tvDelivery = findViewById(R.id.tvTrackDelivery);
        tvTotal = findViewById(R.id.tvTrackTotal);
        tvAddress = findViewById(R.id.tvTrackAddress);
        tvProduct = findViewById(R.id.tvTrackProduct);
        tvQty = findViewById(R.id.tvTrackQty);
        tvPaper = findViewById(R.id.tvTrackPaper);
        tvCustomText = findViewById(R.id.tvTrackCustomText);
        ivTrackDesignPreview = findViewById(R.id.ivTrackDesignPreview);

        tvProgPlaced = findViewById(R.id.tvProgressPlaced);
        tvProgProcessing = findViewById(R.id.tvProgressProcessing);
        tvProgPrinting = findViewById(R.id.tvProgressPrinting);
        tvProgReady = findViewById(R.id.tvProgressReady);
        tvProgDelivered = findViewById(R.id.tvProgressDelivered);

        int orderID = getIntent().getIntExtra(
                AppConstants.KEY_ORDER_ID, -1);
        if (orderID != -1) {
            load(orderID);
        } else {
            finish();
        }
    }

    private void load(int orderID) {
        Order o = orderDAO.getOrderByID(orderID);
        if (o == null) {
            finish();
            return;
        }

        tvOrderID.setText("#" + String.format(
                "%05d", o.getOrderID()));
        tvStatus.setText(o.getStatus());

        // Set status background based on state
        updateProgressUI(o.getStatus(), o.getDeliveryType());

        tvDate.setText(
                o.getOrderDate() != null &&
                        o.getOrderDate().length() >= 10 ?
                        o.getOrderDate().substring(0, 10)
                        : "");
        tvDelivery.setText(o.getDeliveryType());
        tvTotal.setText(String.format(
                "LKR %.2f", o.getTotalAmount()));

        String displayAddress = o.getDeliveryAddress();
        if (AppConstants.DELIVERY_PICKUP.equals(o.getDeliveryType())) {
            displayAddress = AppConstants.STORE_ADDRESS;
        } else if (displayAddress == null || displayAddress.isEmpty()) {
            displayAddress = "Address not provided";
        }
        tvAddress.setText(displayAddress);
        
        tvQty.setText(String.valueOf(o.getQuantity()));
        tvPaper.setText(o.getPaperType());

        if (o.getCustomText() != null && !o.getCustomText().isEmpty()) {
            tvCustomText.setText(o.getCustomText());
            ivTrackDesignPreview.setVisibility(View.GONE);
        } else if (o.getFilePath() != null && !o.getFilePath().isEmpty()) {
            tvCustomText.setText("Design file uploaded");
            
            // Try to show preview if it's an image
            try {
                android.net.Uri uri = android.net.Uri.parse(o.getFilePath());
                String path = o.getFilePath();
                if (path.toLowerCase().endsWith(".jpg") || 
                    path.toLowerCase().endsWith(".jpeg") || 
                    path.toLowerCase().endsWith(".png")) {
                    
                    if (path.startsWith("/")) {
                        ivTrackDesignPreview.setImageURI(android.net.Uri.fromFile(new java.io.File(path)));
                    } else {
                        ivTrackDesignPreview.setImageURI(uri);
                    }
                    ivTrackDesignPreview.setVisibility(View.VISIBLE);
                } else {
                    ivTrackDesignPreview.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                ivTrackDesignPreview.setVisibility(View.GONE);
            }
        } else {
            tvCustomText.setText("No design added");
            ivTrackDesignPreview.setVisibility(View.GONE);
        }

        Product p = productDAO.getProductByID(
                o.getProductID());
        if (p != null)
            tvProduct.setText(p.getName());
    }

    private void updateProgressUI(String status, String deliveryType) {
        int colorHint = getResources().getColor(R.color.text_hint);
        int colorSuccess = getResources().getColor(R.color.success);
        int colorWarning = getResources().getColor(R.color.warning);

        String readyLabel = AppConstants.DELIVERY_HOME.equals(deliveryType) ?
                "Ready for Dispatch" : "Ready for Pickup";

        // Reset all
        tvProgPlaced.setTextColor(colorHint);
        tvProgProcessing.setTextColor(colorHint);
        tvProgPrinting.setTextColor(colorHint);
        tvProgReady.setTextColor(colorHint);
        tvProgDelivered.setTextColor(colorHint);

        tvProgPlaced.setText("[  ] Order Placed");
        tvProgProcessing.setText("[  ] Processing");
        tvProgPrinting.setText("[  ] Printing");
        tvProgReady.setText("[  ] " + readyLabel);
        tvProgDelivered.setText("[  ] Delivered");

        // First step is always done
        tvProgPlaced.setTextColor(colorSuccess);
        tvProgPlaced.setText("[OK] Order Placed");

        if (AppConstants.STATUS_PROCESSING.equals(status)) {
            tvProgProcessing.setTextColor(colorWarning);
            tvProgProcessing.setText("[>>] Processing");
            tvStatus.setBackgroundResource(R.drawable.bg_status_processing);
        } else if (AppConstants.STATUS_PRINTING.equals(status)) {
            tvProgProcessing.setTextColor(colorSuccess);
            tvProgProcessing.setText("[OK] Processing");
            tvProgPrinting.setTextColor(colorWarning);
            tvProgPrinting.setText("[>>] Printing");
            tvStatus.setBackgroundResource(R.drawable.bg_status_printing);
        } else if (AppConstants.STATUS_READY.equals(status)) {
            tvProgProcessing.setTextColor(colorSuccess);
            tvProgProcessing.setText("[OK] Processing");
            tvProgPrinting.setTextColor(colorSuccess);
            tvProgPrinting.setText("[OK] Printing");
            tvProgReady.setTextColor(colorWarning);
            tvProgReady.setText("[>>] " + readyLabel);
            tvStatus.setBackgroundResource(R.drawable.bg_status_ready);
        } else if (AppConstants.STATUS_DELIVERED.equals(status)) {
            tvProgProcessing.setTextColor(colorSuccess);
            tvProgProcessing.setText("[OK] Processing");
            tvProgPrinting.setTextColor(colorSuccess);
            tvProgPrinting.setText("[OK] Printing");
            tvProgReady.setTextColor(colorSuccess);
            tvProgReady.setText("[OK] " + readyLabel);
            tvProgDelivered.setTextColor(colorSuccess);
            tvProgDelivered.setText("[OK] Delivered");
            tvStatus.setBackgroundResource(R.drawable.bg_status_delivered);
        } else if (AppConstants.STATUS_CANCELLED.equals(status)) {
            tvStatus.setBackgroundResource(R.drawable.bg_status_cancelled);
            tvProgProcessing.setText("[X] Cancelled");
            tvProgProcessing.setTextColor(getResources().getColor(R.color.error));
        }
    }
}
