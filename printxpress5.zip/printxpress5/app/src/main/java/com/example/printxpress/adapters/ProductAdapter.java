package com.example.printxpress.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.example.printxpress.R;
import com.example.printxpress.models.Product;
import java.util.List;

public class ProductAdapter extends
        RecyclerView.Adapter<ProductAdapter.VH> {

    public interface OnClick {
        void onOrder(Product product);
    }

    private List<Product> list;
    private OnClick listener;

    public ProductAdapter(List<Product> list,
                          OnClick listener) {
        this.list = list;
        this.listener = listener;
    }

    public void updateList(List<Product> newList) {
        this.list = newList;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(
                parent.getContext()).inflate(
                R.layout.item_product_card,
                parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(
            @NonNull VH holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvMaterial,
                tvSize, tvPrice;
        android.widget.ImageView ivImage;
        MaterialButton btnOrder;

        VH(View v) {
            super(v);
            tvName = v.findViewById(
                    R.id.tvProductName);
            tvMaterial = v.findViewById(
                    R.id.tvProductMaterial);
            tvSize = v.findViewById(
                    R.id.tvProductSize);
            tvPrice = v.findViewById(
                    R.id.tvProductPrice);
            ivImage = v.findViewById(R.id.ivProductImage);
            btnOrder = v.findViewById(R.id.btnOrder);
        }

        void bind(Product p) {
            tvName.setText(p.getName());
            tvMaterial.setText(p.getMaterial());
            // Show the actual size or specs from the product
            tvSize.setText(p.getSize());
            tvPrice.setText(itemView.getContext().getString(R.string.from_rs_prefix, String.format("%.0f", p.getPrice())));
            
            ivImage.setImageResource(getProductIcon(p.getName()));
            
            btnOrder.setOnClickListener(v ->
                    listener.onOrder(p));
            itemView.setOnClickListener(v ->
                    listener.onOrder(p));
        }

        private int getProductIcon(String name) {
            if (name == null) return R.drawable.ic_print;
            String lower = name.toLowerCase();
            if (lower.contains("card")) return R.drawable.ic_cat_business;
            if (lower.contains("flyer")) return R.drawable.ic_cat_flyer;
            if (lower.contains("banner")) return R.drawable.ic_cat_banner;
            if (lower.contains("sticker")) return R.drawable.ic_cat_sticker;
            if (lower.contains("shirt")) return R.drawable.ic_cat_tshirt;
            if (lower.contains("mug")) return R.drawable.ic_cat_mug;
            if (lower.contains("poster")) return R.drawable.ic_cat_poster;
            return R.drawable.ic_print;
        }
    }
}
