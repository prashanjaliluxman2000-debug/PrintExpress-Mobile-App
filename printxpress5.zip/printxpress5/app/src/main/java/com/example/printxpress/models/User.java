package com.example.printxpress.models;

public class User {
    private int userID;
    private String name;
    private String email;
    private String phone;
    private String password;
    private boolean isAdmin;
    private String createdAt;

    public User() {}

    public int getUserID() { return userID; }
    public void setUserID(int v) { userID = v; }

    public String getName() { return name; }
    public void setName(String v) { name = v; }

    public String getEmail() { return email; }
    public void setEmail(String v) { email = v; }

    public String getPhone() { return phone; }
    public void setPhone(String v) { phone = v; }

    public String getPassword() { return password; }
    public void setPassword(String v) { password = v; }

    public boolean isAdmin() { return isAdmin; }
    public void setAdmin(boolean v) { isAdmin = v; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String v) {
        createdAt = v; }
}
