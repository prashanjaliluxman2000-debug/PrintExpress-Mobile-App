package com.example.printxpress.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

public class FileUploadHelper {

    private Context context;

    public FileUploadHelper(Context context) {
        this.context = context;
    }

    public String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor c =
                         context.getContentResolver()
                                 .query(uri, null, null,
                                         null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(
                            OpenableColumns
                                    .DISPLAY_NAME);
                    if (idx >= 0)
                        result = c.getString(idx);
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1)
                    result = result.substring(
                            cut + 1);
            }
        }
        return result;
    }

    public boolean isValidFile(Uri uri) {
        String name = getFileName(uri);
        if (name == null) return false;
        String lower = name.toLowerCase();
        return lower.endsWith(".pdf") ||
                lower.endsWith(".jpg") ||
                lower.endsWith(".jpeg") ||
                lower.endsWith(".png");
    }

    public String copyFileToInternal(Uri uri) {
        try {
            String fileName = "design_" + System.currentTimeMillis() + "_" + getFileName(uri);
            java.io.File file = new java.io.File(context.getFilesDir(), fileName);
            
            try (java.io.InputStream is = context.getContentResolver().openInputStream(uri);
                 java.io.OutputStream os = new java.io.FileOutputStream(file)) {
                
                byte[] buffer = new byte[4096];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    os.write(buffer, 0, read);
                }
                return file.getAbsolutePath();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
