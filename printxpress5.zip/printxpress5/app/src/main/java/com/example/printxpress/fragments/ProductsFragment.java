package com.example.printxpress.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.chip.Chip;
import com.example.printxpress.R;
import com.example.printxpress.activities.PlaceOrderActivity;
import com.example.printxpress.adapters.ProductAdapter;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.ProductDAO;
import com.example.printxpress.models.Category;
import com.example.printxpress.models.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductsFragment extends Fragment {

    private LinearLayout chipGroup;
    private RecyclerView rvProducts;
    private ProductDAO productDAO;
    private ProductAdapter adapter;
    private int selectedCategoryID = -1;

    public static ProductsFragment newInstance(
            int categoryID) {
        ProductsFragment f = new ProductsFragment();
        Bundle args = new Bundle();
        args.putInt("categoryID", categoryID);
        f.setArguments(args);
        return f;
    }

    @Nullable @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(
                R.layout.fragment_products,
                container, false);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        productDAO = new ProductDAO(
                requireContext());
        chipGroup = view.findViewById(
                R.id.chipGroupCategories);
        rvProducts = view.findViewById(
                R.id.rvProducts);

        if (getArguments() != null) {
            selectedCategoryID = getArguments()
                    .getInt("categoryID", -1);
        }

        setupRecyclerView();
        buildChips();
        filterByCategory(selectedCategoryID);
    }

    private void setupRecyclerView() {
        rvProducts.setLayoutManager(
                new LinearLayoutManager(
                        getContext()));
        adapter = new ProductAdapter(
                new ArrayList<>(), p -> {
            Intent intent = new Intent(
                    getContext(),
                    PlaceOrderActivity.class);
            intent.putExtra(
                    AppConstants.KEY_PRODUCT_ID,
                    p.getProductID());
            startActivity(intent);
        });
        rvProducts.setAdapter(adapter);
    }

    private void buildChips() {
        Chip allChip = makeChip("All", -1);
        allChip.setChecked(
                selectedCategoryID == -1);
        chipGroup.addView(allChip);

        for (Category cat :
                productDAO.getAllCategories()) {
            Chip chip = makeChip(
                    cat.getCategoryName(),
                    cat.getCategoryID());
            chip.setChecked(cat.getCategoryID()
                    == selectedCategoryID);
            chipGroup.addView(chip);
        }
    }

    private Chip makeChip(String label,
                          int categoryID) {
        Chip chip = new Chip(requireContext());
        chip.setText(label);
        chip.setCheckable(true);
        chip.setTextSize(13f);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(8);
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> {
            selectedCategoryID = categoryID;
            for (int i = 0;
                 i < chipGroup.getChildCount();
                 i++) {
                View child =
                        chipGroup.getChildAt(i);
                if (child instanceof Chip)
                    ((Chip) child).setChecked(false);
            }
            chip.setChecked(true);
            filterByCategory(categoryID);
        });
        return chip;
    }

    private void filterByCategory(int categoryID) {
        List<Product> list = categoryID == -1 ?
                productDAO.getAllProducts() :
                productDAO.getProductsByCategory(
                        categoryID);
        adapter.updateList(list);
    }
}
