package com.example.printxpress.constants;

public class AppConstants {

    public static final String DB_NAME =
            "printxpress.db";
    public static final int DB_VERSION = 1;

    public static final String PREF_NAME =
            "PrintXpressPrefs";
    public static final String KEY_USER_ID =
            "userID";
    public static final String KEY_USER_NAME =
            "userName";
    public static final String KEY_USER_EMAIL =
            "userEmail";
    public static final String KEY_IS_LOGGED_IN =
            "isLoggedIn";
    public static final String KEY_IS_ADMIN =
            "isAdmin";

    public static final String STATUS_PROCESSING =
            "Processing";
    public static final String STATUS_PRINTING =
            "Printing";
    public static final String STATUS_READY =
            "Ready for Dispatch";
    public static final String STATUS_DELIVERED =
            "Delivered";
    public static final String STATUS_CANCELLED =
            "Cancelled";

    public static final String DELIVERY_PICKUP =
            "Store Pickup";
    public static final String DELIVERY_HOME =
            "Home Delivery";

    public static final String KEY_PRODUCT_ID =
            "productID";
    public static final String KEY_ORDER_ID =
            "orderID";
    public static final String KEY_CATEGORY_ID =
            "categoryID";

    public static final String STORE_ADDRESS =
            "No. 123, Galle Road, Colombo 03, Sri Lanka";
}
