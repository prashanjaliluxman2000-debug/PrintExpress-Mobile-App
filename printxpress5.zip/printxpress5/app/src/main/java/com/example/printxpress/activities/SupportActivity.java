package com.example.printxpress.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;

public class SupportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        LinearLayout rowEmail = findViewById(
                R.id.rowEmail);
        LinearLayout rowPhone = findViewById(
                R.id.rowPhone);
        LinearLayout rowWhatsApp = findViewById(
                R.id.rowWhatsApp);
        LinearLayout rowFAQ = findViewById(
                R.id.rowFAQ);

        rowEmail.setOnClickListener(v -> {
            Intent i = new Intent(
                    Intent.ACTION_SENDTO);
            i.setData(Uri.parse(
                    "mailto:support@printxpress.lk"));
            startActivity(i);
        });

        rowPhone.setOnClickListener(v -> {
            Intent i = new Intent(
                    Intent.ACTION_DIAL);
            i.setData(Uri.parse(
                    "tel:+94112345678"));
            startActivity(i);
        });

        rowWhatsApp.setOnClickListener(v -> {
            Intent i = new Intent(
                    Intent.ACTION_VIEW);
            i.setData(Uri.parse(
                    "https://wa.me/94112345678"));
            startActivity(i);
        });

        rowFAQ.setOnClickListener(v ->
                showFAQ());
    }

    private void showFAQ() {
        String msg =
                "Q: What file formats accepted?\n" +
                        "A: PDF, JPG, PNG\n\n" +
                        "Q: Minimum resolution?\n" +
                        "A: 300 DPI\n\n" +
                        "Q: How long does printing take?\n" +
                        "A: 1-3 business days\n\n" +
                        "Q: Do you deliver?\n" +
                        "A: Yes, across Sri Lanka\n\n" +
                        "Q: Can I cancel my order?\n" +
                        "A: Yes, before printing begins\n\n" +
                        "Q: What is bleed margin?\n" +
                        "A: 3mm extra on all sides";

        new androidx.appcompat.app.AlertDialog
                .Builder(this)
                .setTitle("FAQ - PrintXpress")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }
}
