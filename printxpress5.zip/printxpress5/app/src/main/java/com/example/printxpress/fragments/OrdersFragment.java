package com.example.printxpress.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.activities.MainActivity;
import com.example.printxpress.activities.OrderTrackingActivity;
import com.example.printxpress.adapters.OrderAdapter;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.OrderDAO;
import com.example.printxpress.models.Order;
import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment {

    private RecyclerView rvOrders;
    private LinearLayout layoutEmpty;
    private OrderAdapter adapter;
    private OrderDAO orderDAO;

    @Nullable @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(
                R.layout.fragment_orders,
                container, false);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        orderDAO = new OrderDAO(requireContext());
        rvOrders = view.findViewById(R.id.rvOrders);
        layoutEmpty = view.findViewById(
                R.id.layoutEmpty);

        rvOrders.setLayoutManager(
                new LinearLayoutManager(
                        getContext()));
        adapter = new OrderAdapter(
                new ArrayList<>(),
                this::cancelOrder,
                this::trackOrder);
        rvOrders.setAdapter(adapter);
        loadOrders();
    }

    private void loadOrders() {
        List<Order> orders =
                orderDAO.getOrdersByUser(
                        MainActivity.loggedInUserID);
        adapter.updateList(orders);
        if (orders.isEmpty()) {
            rvOrders.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.VISIBLE);
        } else {
            rvOrders.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);
        }
    }

    private void cancelOrder(Order order) {
        new androidx.appcompat.app.AlertDialog
                .Builder(requireContext())
                .setTitle("Cancel Order")
                .setMessage("Cancel Order #" +
                        order.getOrderID() + "?")
                .setPositiveButton("Yes", (d, w) -> {
                    if (orderDAO.cancelOrder(
                            order.getOrderID())) {
                        loadOrders();
                        showSnack("Order cancelled!");
                    } else {
                        showSnack(
                                "Cannot cancel - " +
                                        "already being processed!");
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void trackOrder(Order order) {
        Intent intent = new Intent(
                getContext(),
                OrderTrackingActivity.class);
        intent.putExtra(
                AppConstants.KEY_ORDER_ID,
                order.getOrderID());
        startActivity(intent);
    }

    private void showSnack(String msg) {
        if (getView() != null)
            com.google.android.material.snackbar
                    .Snackbar.make(getView(), msg,
                            com.google.android.material
                                    .snackbar.Snackbar.LENGTH_LONG)
                    .show();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadOrders();
    }
}