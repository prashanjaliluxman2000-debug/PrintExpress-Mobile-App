package com.example.printxpress.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.printxpress.models.Address;
import java.util.ArrayList;
import java.util.List;

public class AddressDAO {

    private DBHelper dbHelper;

    public AddressDAO(Context context) {
        dbHelper = DBHelper.getInstance(context);
    }

    public long addAddress(Address address) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.A_USER_ID,
                address.getUserID());
        cv.put(DBHelper.A_LINE,
                address.getAddressLine());
        cv.put(DBHelper.A_CITY, address.getCity());
        cv.put(DBHelper.A_DEFAULT,
                address.isDefault() ? "1" : "0");
        return db.insert(
                DBHelper.TABLE_ADDRESSES, null, cv);
    }

    public List<Address> getAddressByUser(
            int userID) {
        List<Address> list = new ArrayList<>();
        SQLiteDatabase db =
                dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT * FROM " +
                        DBHelper.TABLE_ADDRESSES +
                        " WHERE " + DBHelper.A_USER_ID +
                        "=?",
                new String[]{
                        String.valueOf(userID)});
        while (c.moveToNext()) {
            Address a = new Address();
            a.setAddressID(c.getInt(
                    c.getColumnIndexOrThrow(
                            DBHelper.A_ID)));
            a.setUserID(c.getInt(
                    c.getColumnIndexOrThrow(
                            DBHelper.A_USER_ID)));
            a.setAddressLine(c.getString(
                    c.getColumnIndexOrThrow(
                            DBHelper.A_LINE)));
            a.setCity(c.getString(
                    c.getColumnIndexOrThrow(
                            DBHelper.A_CITY)));
            a.setDefault(c.getString(
                            c.getColumnIndexOrThrow(
                                    DBHelper.A_DEFAULT))
                    .equals("1"));
            list.add(a);
        }
        c.close();
        return list;
    }

    public boolean deleteAddress(int addressID) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        int rows = db.delete(
                DBHelper.TABLE_ADDRESSES,
                DBHelper.A_ID + "=?",
                new String[]{
                        String.valueOf(addressID)});
        return rows > 0;
    }
}
