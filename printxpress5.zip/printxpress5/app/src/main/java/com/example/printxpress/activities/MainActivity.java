package com.example.printxpress.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.example.printxpress.R;
import com.example.printxpress.utils.SessionManager;
import com.example.printxpress.fragments.HomeFragment;
import com.example.printxpress.fragments.ProductsFragment;
import com.example.printxpress.fragments.OrdersFragment;
import com.example.printxpress.fragments.NotificationsFragment;
import com.example.printxpress.fragments.ProfileFragment;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    public static int loggedInUserID = -1;
    public static String loggedInUserName = "";

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SessionManager session =
                new SessionManager(this);

        if (!session.isLoggedIn()) {
            startActivity(new Intent(this,
                    LoginActivity.class));
            finish();
            return;
        }

        if (session.isAdmin()) {
            startActivity(new Intent(this,
                    AdminActivity.class));
            finish();
            return;
        }

        loggedInUserID = session.getUserID();
        loggedInUserName = session.getUserName();

        bottomNav = findViewById(R.id.bottomNav);
        loadFragment(new HomeFragment());

        bottomNav.setOnItemSelectedListener(
                item -> {
                    int id = item.getItemId();
                    if (id == R.id.nav_home)
                        loadFragment(new HomeFragment());
                    else if (id == R.id.nav_products)
                        loadFragment(new ProductsFragment());
                    else if (id == R.id.nav_orders)
                        loadFragment(new OrdersFragment());
                    else if (id == R.id.nav_notifications)
                        loadFragment(
                                new NotificationsFragment());
                    else if (id == R.id.nav_profile)
                        loadFragment(new ProfileFragment());
                    return true;
                });
    }

    public void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    public void navigateToProducts() {
        bottomNav.setSelectedItemId(
                R.id.nav_products);
    }

    public void navigateToOrders() {
        bottomNav.setSelectedItemId(R.id.nav_orders);
    }

    public void navigateToNotifications() {
        bottomNav.setSelectedItemId(
                R.id.nav_notifications);
    }

    public void navigateToProductsByCategory(
            int categoryID) {
        bottomNav.setSelectedItemId(
                R.id.nav_products);
        loadFragment(ProductsFragment
                .newInstance(categoryID));
    }
}
