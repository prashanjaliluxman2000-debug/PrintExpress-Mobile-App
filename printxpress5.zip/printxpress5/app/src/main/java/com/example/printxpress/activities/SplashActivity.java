package com.example.printxpress.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.example.printxpress.R;
import com.example.printxpress.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SessionManager session =
                    new SessionManager(this);
            if (session.isLoggedIn()) {
                if (session.isAdmin()) {
                    startActivity(new Intent(
                            this,
                            AdminActivity.class));
                } else {
                    startActivity(new Intent(
                            this,
                            MainActivity.class));
                }
            } else {
                startActivity(new Intent(
                        this,
                        LoginActivity.class));
            }
            finish();
        }, 2500);
    }
}
