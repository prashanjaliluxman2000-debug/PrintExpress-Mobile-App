package com.example.printxpress.models;

public class Category {
    private int categoryID;
    private String categoryName;
    private String icon;

    public Category() {}

    public int getCategoryID() { return categoryID; }
    public void setCategoryID(int v) {
        categoryID = v; }

    public String getCategoryName() {
        return categoryName; }
    public void setCategoryName(String v) {
        categoryName = v; }

    public String getIcon() { return icon; }
    public void setIcon(String v) { icon = v; }
}
