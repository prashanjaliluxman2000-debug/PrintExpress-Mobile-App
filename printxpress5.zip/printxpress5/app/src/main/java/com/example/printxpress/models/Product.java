package com.example.printxpress.models;

public class Product {
    private int productID;
    private int categoryID;
    private String name;
    private String description;
    private String material;
    private String size;
    private double price;
    private String image;

    public Product() {}

    public int getProductID() { return productID; }
    public void setProductID(int v) { productID = v; }

    public int getCategoryID() { return categoryID; }
    public void setCategoryID(int v) {
        categoryID = v; }

    public String getName() { return name; }
    public void setName(String v) { name = v; }

    public String getDescription() {
        return description; }
    public void setDescription(String v) {
        description = v; }

    public String getMaterial() { return material; }
    public void setMaterial(String v) { material = v; }

    public String getSize() { return size; }
    public void setSize(String v) { size = v; }

    public double getPrice() { return price; }
    public void setPrice(double v) { price = v; }

    public String getImage() { return image; }
    public void setImage(String v) { image = v; }
}
