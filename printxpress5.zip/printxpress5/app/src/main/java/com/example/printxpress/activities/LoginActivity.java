package com.example.printxpress.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.printxpress.R;
import com.example.printxpress.database.UserDAO;
import com.example.printxpress.models.User;
import com.example.printxpress.utils.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilEmail, tilPassword;
    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView tvRegister;
    private UserDAO userDAO;
    private SessionManager session;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userDAO = new UserDAO(this);
        session = new SessionManager(this);

        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> login());
        tvRegister.setOnClickListener(v ->
                startActivity(new Intent(this,
                        RegisterActivity.class)));
    }

    private void login() {
        String email = etEmail.getText() != null ?
                etEmail.getText().toString().trim()
                : "";
        String pwd = etPassword.getText() != null ?
                etPassword.getText().toString() : "";

        boolean valid = true;
        if (TextUtils.isEmpty(email)) {
            tilEmail.setError(
                    "Email or phone required");
            valid = false;
        } else tilEmail.setError(null);

        if (TextUtils.isEmpty(pwd)) {
            tilPassword.setError(
                    "Password required");
            valid = false;
        } else tilPassword.setError(null);

        if (!valid) return;

        btnLogin.setEnabled(false);
        btnLogin.setText("Logging in...");

        User user = userDAO.loginUser(email, pwd);

        if (user != null) {
            session.saveSession(
                    user.getUserID(),
                    user.getName(),
                    user.getEmail(),
                    user.isAdmin());

            if (user.isAdmin()) {
                startActivity(new Intent(this,
                        AdminActivity.class));
            } else {
                startActivity(new Intent(this,
                        MainActivity.class));
            }
            finish();
        } else {
            tilPassword.setError(
                    "Invalid credentials!");
            btnLogin.setEnabled(true);
            btnLogin.setText("Login");
        }
    }
}
