package com.example.printxpress.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.example.printxpress.R;
import com.example.printxpress.database.UserDAO;
import com.example.printxpress.models.User;
import com.example.printxpress.utils.ValidationHelper;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout tilName, tilEmail,
            tilPhone, tilPassword, tilConfirm;
    private TextInputEditText etName, etEmail,
            etPhone, etPassword, etConfirm;
    private MaterialButton btnRegister;
    private TextView tvLogin;
    private UserDAO userDAO;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userDAO = new UserDAO(this);

        tilName = findViewById(R.id.tilName);
        tilEmail = findViewById(R.id.tilEmail);
        tilPhone = findViewById(R.id.tilPhone);
        tilPassword = findViewById(R.id.tilPassword);
        tilConfirm = findViewById(
                R.id.tilConfirmPassword);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        etConfirm = findViewById(
                R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(v ->
                register());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void register() {
        String name = etName.getText() != null ?
                etName.getText().toString().trim()
                : "";
        String email = etEmail.getText() != null ?
                etEmail.getText().toString().trim()
                : "";
        String phone = etPhone.getText() != null ?
                etPhone.getText().toString().trim()
                : "";
        String pwd = etPassword.getText() != null ?
                etPassword.getText().toString() : "";
        String confirm =
                etConfirm.getText() != null ?
                        etConfirm.getText().toString() : "";

        boolean valid = true;

        if (!ValidationHelper.isValidName(name)) {
            tilName.setError(
                    "Min 2 characters required");
            valid = false;
        } else tilName.setError(null);

        if (!ValidationHelper.isValidEmail(email)) {
            tilEmail.setError(
                    "Enter valid email");
            valid = false;
        } else if (userDAO.isEmailExists(email)) {
            tilEmail.setError(
                    "Email already registered");
            valid = false;
        } else tilEmail.setError(null);

        if (!ValidationHelper.isValidPhone(phone)) {
            tilPhone.setError(
                    "Enter valid phone (10-15 digits)");
            valid = false;
        } else if (userDAO.isPhoneExists(phone)) {
            tilPhone.setError(
                    "Phone already registered");
            valid = false;
        } else tilPhone.setError(null);

        if (!ValidationHelper
                .isValidPassword(pwd)) {
            tilPassword.setError(
                    "Min 6 chars, 1 uppercase, " +
                            "1 number");
            valid = false;
        } else tilPassword.setError(null);

        if (!pwd.equals(confirm)) {
            tilConfirm.setError(
                    "Passwords do not match");
            valid = false;
        } else tilConfirm.setError(null);

        if (!valid) return;

        btnRegister.setEnabled(false);
        btnRegister.setText("Creating...");

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(pwd);

        long result = userDAO.registerUser(user);

        if (result != -1) {
            new androidx.appcompat.app.AlertDialog
                    .Builder(this)
                    .setTitle("Success!")
                    .setMessage(
                            "Account created! Please login.")
                    .setPositiveButton("Login",
                            (d, w) -> {
                                startActivity(new Intent(this,
                                        LoginActivity.class));
                                finish();
                            })
                    .setCancelable(false)
                    .show();
        } else {
            tilEmail.setError(
                    "Registration failed. Try again.");
            btnRegister.setEnabled(true);
            btnRegister.setText("Create Account");
        }
    }
}
