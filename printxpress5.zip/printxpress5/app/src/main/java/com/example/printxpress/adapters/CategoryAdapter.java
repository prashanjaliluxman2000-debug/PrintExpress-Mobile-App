package com.example.printxpress.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.models.Category;
import java.util.List;

public class CategoryAdapter extends
        RecyclerView.Adapter<CategoryAdapter.VH> {

    public interface OnClick {
        void onClick(int categoryID);
    }

    private List<Category> list;
    private final OnClick listener;

    public CategoryAdapter(List<Category> list,
                           OnClick listener) {
        this.list = list;
        this.listener = listener;
    }

    public void updateList(List<Category> newList) {
        this.list = newList;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public CategoryAdapter.VH onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(
                parent.getContext()).inflate(
                R.layout.item_category_chip,
                parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(
            @NonNull VH holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class VH extends RecyclerView.ViewHolder {
        TextView tvName;
        ImageView ivIcon;
        View container;

        VH(View v) {
            super(v);
            tvName = v.findViewById(
                    R.id.tvCategoryName);
            ivIcon = v.findViewById(
                    R.id.ivCategoryIcon);
            container = v.findViewById(
                    R.id.chipContainer);
        }

        void bind(Category cat) {
            tvName.setText(cat.getCategoryName());
            ivIcon.setImageResource(getCategoryIcon(cat.getCategoryName()));
            
            // Set dynamic pastel background based on category
            setPastelBackground(container, cat.getCategoryName());
            
            container.setOnClickListener(v ->
                    listener.onClick(
                            cat.getCategoryID()));
        }

        private void setPastelBackground(View view, String name) {
            int color;
            switch (name) {
                case "Business Cards": color = 0xFFFFEBEE; break; // Red
                case "Flyers": color = 0xFFE1F5FE; break; // Blue
                case "Banners": color = 0xFFF1F8E9; break; // Green
                case "Stickers": color = 0xFFFFF3E0; break; // Orange
                case "T-Shirts": color = 0xFFF3E5F5; break; // Purple
                case "Mugs": color = 0xFFE0F2F1; break; // Teal
                case "Posters": color = 0xFFFFFDE7; break; // Yellow
                default: color = 0xFFE3F2FD; break;
            }
            android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
            shape.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            shape.setCornerRadius(32f); // Rounded square
            shape.setColor(color);
            view.setBackground(shape);
        }
    }

    private int getCategoryIcon(String name) {
        switch (name) {
            case "Business Cards":
                return R.drawable.ic_cat_business;
            case "Flyers":
                return R.drawable.ic_cat_flyer;
            case "Banners":
                return R.drawable.ic_cat_banner;
            case "Stickers":
                return R.drawable.ic_cat_sticker;
            case "T-Shirts":
                return R.drawable.ic_cat_tshirt;
            case "Mugs":
                return R.drawable.ic_cat_mug;
            case "Posters":
                return R.drawable.ic_cat_poster;
            default:
                return R.drawable.ic_print;
        }
    }
}
