package com.example.printxpress.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.printxpress.constants.AppConstants;
import java.security.MessageDigest;

public class DBHelper extends SQLiteOpenHelper {

    // Table Names
    public static final String TABLE_USERS =
            "users";
    public static final String TABLE_CATEGORIES =
            "categories";
    public static final String TABLE_PRODUCTS =
            "products";
    public static final String TABLE_ORDERS =
            "orders";
    public static final String TABLE_ADDRESSES =
            "addresses";
    public static final String TABLE_PROMOTIONS =
            "promotions";
    public static final String TABLE_NOTIFICATIONS =
            "notifications";

    // Users Columns
    public static final String U_ID = "user_id";
    public static final String U_NAME = "name";
    public static final String U_EMAIL = "email";
    public static final String U_PHONE = "phone";
    public static final String U_PASSWORD = "password";
    public static final String U_IS_ADMIN = "is_admin";
    public static final String U_CREATED = "created_at";

    // Categories Columns
    public static final String C_ID = "category_id";
    public static final String C_NAME = "category_name";
    public static final String C_ICON = "icon";

    // Products Columns
    public static final String P_ID = "product_id";
    public static final String P_CAT_ID = "category_id";
    public static final String P_NAME = "name";
    public static final String P_DESC = "description";
    public static final String P_MATERIAL = "material";
    public static final String P_SIZE = "size";
    public static final String P_PRICE = "price";
    public static final String P_IMAGE = "image";

    // Orders Columns
    public static final String O_ID = "order_id";
    public static final String O_USER_ID = "user_id";
    public static final String O_PRODUCT_ID =
            "product_id";
    public static final String O_DATE = "order_date";
    public static final String O_STATUS = "status";
    public static final String O_DELIVERY =
            "delivery_type";
    public static final String O_ADDRESS =
            "delivery_address";
    public static final String O_TOTAL = "total_amount";
    public static final String O_NOTES = "notes";
    public static final String O_FILE = "file_path";
    public static final String O_CUSTOM_TEXT =
            "custom_text";
    public static final String O_PAPER = "paper_type";
    public static final String O_QTY = "quantity";

    // Addresses Columns
    public static final String A_ID = "address_id";
    public static final String A_USER_ID = "user_id";
    public static final String A_LINE = "address_line";
    public static final String A_CITY = "city";
    public static final String A_DEFAULT = "is_default";

    // Promotions Columns
    public static final String PR_ID = "promo_id";
    public static final String PR_TITLE = "title";
    public static final String PR_DESC = "description";
    public static final String PR_DISCOUNT =
            "discount_percent";
    public static final String PR_START = "start_date";
    public static final String PR_END = "end_date";

    // Notifications Columns
    public static final String N_ID = "notif_id";
    public static final String N_USER_ID = "user_id";
    public static final String N_TITLE = "title";
    public static final String N_MESSAGE = "message";
    public static final String N_READ = "is_read";
    public static final String N_DATE = "created_at";

    private static DBHelper instance;

    public static synchronized DBHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DBHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DBHelper(Context context) {
        super(context, AppConstants.DB_NAME,
                null, AppConstants.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_USERS +
                "(" + U_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                U_NAME + " TEXT NOT NULL," +
                U_EMAIL + " TEXT UNIQUE," +
                U_PHONE + " TEXT UNIQUE," +
                U_PASSWORD + " TEXT NOT NULL," +
                U_IS_ADMIN + " INTEGER DEFAULT 0," +
                U_CREATED +
                " DATETIME DEFAULT CURRENT_TIMESTAMP)");

        db.execSQL("CREATE TABLE " + TABLE_CATEGORIES +
                "(" + C_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                C_NAME + " TEXT NOT NULL," +
                C_ICON + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_PRODUCTS +
                "(" + P_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                P_CAT_ID + " INTEGER," +
                P_NAME + " TEXT NOT NULL," +
                P_DESC + " TEXT," +
                P_MATERIAL + " TEXT," +
                P_SIZE + " TEXT," +
                P_PRICE + " REAL NOT NULL," +
                P_IMAGE + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_ORDERS +
                "(" + O_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                O_USER_ID + " INTEGER NOT NULL," +
                O_PRODUCT_ID + " INTEGER," +
                O_DATE +
                " DATETIME DEFAULT CURRENT_TIMESTAMP," +
                O_STATUS + " TEXT DEFAULT 'Processing'," +
                O_DELIVERY + " TEXT," +
                O_ADDRESS + " TEXT," +
                O_TOTAL + " REAL NOT NULL," +
                O_NOTES + " TEXT," +
                O_FILE + " TEXT," +
                O_CUSTOM_TEXT + " TEXT," +
                O_PAPER + " TEXT," +
                O_QTY + " INTEGER DEFAULT 1)");

        db.execSQL("CREATE TABLE " + TABLE_ADDRESSES +
                "(" + A_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                A_USER_ID + " INTEGER NOT NULL," +
                A_LINE + " TEXT NOT NULL," +
                A_CITY + " TEXT," +
                A_DEFAULT + " TEXT DEFAULT '0')");

        db.execSQL("CREATE TABLE " + TABLE_PROMOTIONS +
                "(" + PR_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                PR_TITLE + " TEXT NOT NULL," +
                PR_DESC + " TEXT," +
                PR_DISCOUNT + " INTEGER," +
                PR_START + " DATE," +
                PR_END + " DATE)");

        db.execSQL("CREATE TABLE " +
                TABLE_NOTIFICATIONS + "(" + N_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," +
                N_USER_ID + " INTEGER NOT NULL," +
                N_TITLE + " TEXT," +
                N_MESSAGE + " TEXT NOT NULL," +
                N_READ + " INTEGER DEFAULT 0," +
                N_DATE +
                " DATETIME DEFAULT CURRENT_TIMESTAMP)");

        insertSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_NOTIFICATIONS);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_PROMOTIONS);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_ADDRESSES);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_ORDERS);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_PRODUCTS);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_CATEGORIES);
        db.execSQL("DROP TABLE IF EXISTS " +
                TABLE_USERS);
        onCreate(db);
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");
            byte[] hash =
                    digest.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                String hex =
                        Integer.toHexString(0xff & b);
                if (hex.length() == 1) sb.append('0');
                sb.append(hex);
            }
            return sb.toString();
        } catch (Exception e) {
            return password;
        }
    }

    private void insertSampleData(SQLiteDatabase db) {

        // Admin User - cannot register
        db.execSQL("INSERT INTO " + TABLE_USERS +
                "(name,email,phone,password,is_admin)" +
                " VALUES('Admin User'," +
                "'admin@printxpress.lk'," +
                "'0112345678','" +
                hashPassword("Admin@123") + "',1)");

        // Categories
        String[] categories = {
                "Business Cards",
                "Flyers",
                "Banners",
                "Stickers",
                "T-Shirts",
                "Mugs",
                "Posters"
        };
        for (String cat : categories) {
            db.execSQL("INSERT INTO " +
                    TABLE_CATEGORIES +
                    "(category_name) VALUES('" +
                    cat + "')");
        }

        // Products
        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(1,'Standard Business Card'," +
                "'Professional quality cards'," +
                "'350gsm Matt','90x55mm',1500)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(1,'Premium Business Card'," +
                "'Luxury finish cards'," +
                "'400gsm Gloss','90x55mm',2500)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(2,'A5 Flyer'," +
                "'Single sided color flyer'," +
                "'130gsm Silk','A5',3500)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(2,'A4 Flyer'," +
                "'Double sided color flyer'," +
                "'170gsm Silk','A4',5000)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(3,'Roll Up Banner'," +
                "'Premium pull up banner'," +
                "'PVC Vinyl','85x200cm',15000)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(3,'Outdoor Banner'," +
                "'Weatherproof flex banner'," +
                "'Flex','3x6 feet',8000)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(4,'Custom Sticker'," +
                "'Waterproof vinyl sticker'," +
                "'Vinyl','Custom',800)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(5,'Custom T-Shirt'," +
                "'Full color printed shirt'," +
                "'Cotton','S/M/L/XL',1800)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(6,'Custom Mug'," +
                "'Printed ceramic mug'," +
                "'Ceramic','11oz',1200)");

        db.execSQL("INSERT INTO " + TABLE_PRODUCTS +
                "(category_id,name,description," +
                "material,size,price) VALUES" +
                "(7,'A3 Poster'," +
                "'High resolution poster'," +
                "'200gsm Gloss','A3',2000)");

        // Promotions
        db.execSQL("INSERT INTO " + TABLE_PROMOTIONS +
                "(title,description," +
                "discount_percent,start_date,end_date)" +
                " VALUES('New Customer Offer'," +
                "'10% off on your first order'," +
                "10,'2026-01-01','2026-12-31')");

        db.execSQL("INSERT INTO " + TABLE_PROMOTIONS +
                "(title,description," +
                "discount_percent,start_date,end_date)" +
                " VALUES('Bulk Print Deal'," +
                "'20% off on orders above 100'," +
                "20,'2026-01-01','2026-12-31')");

        db.execSQL("INSERT INTO " + TABLE_PROMOTIONS +
                "(title,description," +
                "discount_percent,start_date,end_date)" +
                " VALUES('Festive Season Sale'," +
                "'15% off on all products'," +
                "15,'2026-04-01','2026-12-31')");
    }
}
