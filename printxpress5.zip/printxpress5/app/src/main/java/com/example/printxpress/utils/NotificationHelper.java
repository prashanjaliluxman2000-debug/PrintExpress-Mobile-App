package com.example.printxpress.utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.example.printxpress.R;
import com.example.printxpress.constants.AppConstants;
import com.example.printxpress.database.DBHelper;

public class NotificationHelper {

    private static final String CHANNEL_ID =
            "PrintXpress";
    private Context context;
    private NotificationManager manager;
    private DBHelper dbHelper;

    public NotificationHelper(Context context) {
        this.context = context;
        this.dbHelper = DBHelper.getInstance(context);
        manager = (NotificationManager)
                context.getSystemService(
                        Context.NOTIFICATION_SERVICE);
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "PrintXpress Notifications",
                            NotificationManager.IMPORTANCE_DEFAULT);
            manager.createNotificationChannel(channel);
        }
    }

    // Show system notification
    private void showSystem(String title,
                            String message) {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        context, CHANNEL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentText(message)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat
                                .PRIORITY_DEFAULT);
        manager.notify(
                (int) System.currentTimeMillis(),
                builder.build());
    }

    // Save to database notifications table
    public void saveToDatabase(int userID,
                               String title,
                               String message) {
        SQLiteDatabase db =
                dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.N_USER_ID, userID);
        cv.put(DBHelper.N_TITLE, title);
        cv.put(DBHelper.N_MESSAGE, message);
        cv.put(DBHelper.N_READ, 0);
        db.insert(DBHelper.TABLE_NOTIFICATIONS,
                null, cv);
    }

    // Order confirmed - call this when order placed
    public void orderConfirmed(int orderID,
                               int userID) {
        String title = "Order Confirmed!";
        String message = "Your order #" +
                String.format("%05d", orderID) +
                " has been placed successfully.";
        saveToDatabase(userID, title, message);
        showSystem(title, message);
    }

    // Order status updated - call when admin changes
    public void orderStatusUpdated(int orderID,
                                   int userID,
                                   String status) {
        String title = "Order Status Updated";
        String message = "Order #" +
                String.format("%05d", orderID) +
                " is now: " + status;

        if (AppConstants.STATUS_READY.equals(status)) {
            String deliveryType = getDeliveryType(orderID);
            if (AppConstants.DELIVERY_HOME.equals(deliveryType)) {
                title = "Order Ready for Dispatch!";
                message = "Your order #" + String.format("%05d", orderID) +
                        " is ready and will be delivered to your address soon.";
            } else {
                title = "Order Ready for Pickup!";
                message = "Your order #" + String.format("%05d", orderID) +
                        " is ready at " + AppConstants.STORE_ADDRESS;
            }
        } else if (AppConstants.STATUS_DELIVERED.equals(status)) {
            title = "Order Delivered!";
            message = "Your order #" + String.format("%05d", orderID) +
                    " has been delivered. Thank you!";
        }

        saveToDatabase(userID, title, message);
        showSystem(title, message);
    }

    private String getDeliveryType(int orderID) {
        String type = "";
        try (android.database.Cursor c = dbHelper.getReadableDatabase().rawQuery(
                "SELECT " + DBHelper.O_DELIVERY + " FROM " + DBHelper.TABLE_ORDERS +
                        " WHERE " + DBHelper.O_ID + "=?", new String[]{String.valueOf(orderID)})) {
            if (c.moveToFirst()) {
                type = c.getString(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return type;
    }

    // Promo notification
    public void promoNotification(int userID,
                                  String promoTitle,
                                  int discount) {
        String title = "Special Offer!";
        String message = promoTitle +
                " - Get " + discount + "% OFF!";
        saveToDatabase(userID, title, message);
        showSystem(title, message);
    }
}

