package com.example.printxpress.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import com.example.printxpress.models.Promotion;
import java.util.List;

public class PromotionAdapter extends
        RecyclerView.Adapter<PromotionAdapter.VH> {

    private List<Promotion> list;

    public PromotionAdapter(List<Promotion> list) {
        this.list = list;
    }

    @NonNull @Override
    public VH onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(
                parent.getContext()).inflate(
                R.layout.item_promo_banner,
                parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(
            @NonNull VH holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDesc, tvDiscount;

        VH(View v) {
            super(v);
            tvTitle = v.findViewById(
                    R.id.tvPromoTitle);
            tvDesc = v.findViewById(
                    R.id.tvPromoDesc);
            tvDiscount = v.findViewById(
                    R.id.tvPromoDiscount);
        }

        void bind(Promotion p) {
            tvTitle.setText(p.getTitle());
            tvDesc.setText(p.getDescription());
            tvDiscount.setText(
                    p.getDiscountPercent() +
                            "%\nOFF");
        }
    }
}
