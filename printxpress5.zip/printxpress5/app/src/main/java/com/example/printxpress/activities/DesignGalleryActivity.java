package com.example.printxpress.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.printxpress.R;
import java.util.ArrayList;
import java.util.List;

public class DesignGalleryActivity extends AppCompatActivity {

    private static class GalleryItem {
        String title;
        int icon;
        GalleryItem(String t, int i) { this.title = t; this.icon = i; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design_gallery);

        RecyclerView rv = findViewById(R.id.rvGallery);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        List<GalleryItem> designs = new ArrayList<>();
        designs.add(new GalleryItem("Modern Business Card", R.drawable.ic_cat_business));
        designs.add(new GalleryItem("Corporate Flyer", R.drawable.ic_cat_flyer));
        designs.add(new GalleryItem("Minimalist Poster", R.drawable.ic_cat_poster));
        designs.add(new GalleryItem("Event Banner", R.drawable.ic_cat_banner));
        designs.add(new GalleryItem("Custom T-Shirt Art", R.drawable.ic_cat_tshirt));
        designs.add(new GalleryItem("Creative Mug Design", R.drawable.ic_cat_mug));

        rv.setAdapter(new RecyclerView.Adapter<VH>() {
            @NonNull
            @Override
            public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_gallery_image, parent, false);
                return new VH(v);
            }

            @Override
            public void onBindViewHolder(@NonNull VH holder, int position) {
                GalleryItem item = designs.get(position);
                holder.tv.setText(item.title);
                holder.iv.setImageResource(item.icon);
                // Apply primary tint to icons
                holder.iv.setColorFilter(androidx.core.content.ContextCompat.getColor(DesignGalleryActivity.this, R.color.primary));
            }

            @Override
            public int getItemCount() {
                return designs.size();
            }
        });
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv;
        ImageView iv;
        VH(View v) {
            super(v);
            tv = v.findViewById(R.id.tvGalleryTitle);
            iv = v.findViewById(R.id.ivGallery);
        }
    }
}
